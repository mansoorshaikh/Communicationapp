//
//  TestViewController.h
//  Communication
//
//  Created by mansoor shaikh on 21/04/14.
//  Copyright (c) 2014 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController
@property(nonatomic,retain) IBOutlet UILabel *testLabel;
@end
