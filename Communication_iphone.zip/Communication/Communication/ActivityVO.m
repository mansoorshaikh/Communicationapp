//
//  ActivityVO.m
//  Communication
//
//  Created by mansoor shaikh on 27/03/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "ActivityVO.h"

@implementation ActivityVO

@end
