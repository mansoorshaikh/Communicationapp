//
//  FeedVO.h
//  Communication
//
//  Created by mansoor shaikh on 28/03/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FeedVO : NSObject
@property(nonatomic,retain) NSString *feedid,*feedtype;
@end
