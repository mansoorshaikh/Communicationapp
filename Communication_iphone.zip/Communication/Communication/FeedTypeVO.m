//
//  FeedTypeVO.m
//  Communication
//
//  Created by mansoor shaikh on 28/03/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "FeedTypeVO.h"

@implementation FeedTypeVO

@end
