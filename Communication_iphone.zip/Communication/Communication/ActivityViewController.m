//
//  ActivityViewController.m
//  CommunicationApp
//
//  Created by mansoor shaikh on 14/04/14.
//  Copyright (c) 2014 MobiWebCode. All rights reserved.
//

#import "ActivityViewController.h"
#import "SWRevealViewController.h"
#import "ActivityVO.h"
#import "AsyncImageView.h"
@interface ActivityViewController ()

@end

@implementation ActivityViewController
@synthesize appDelegate,activityDetailsArray,activityIndicator,tableViewMain;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)setFontFamily:(NSString*)fontFamily forView:(UIView*)view andSubViews:(BOOL)isSubViews
{
    if ([view isKindOfClass:[UILabel class]])
    {
        UILabel *lbl = (UILabel *)view;
        [lbl setFont:[UIFont fontWithName:fontFamily size:[[lbl font] pointSize]]];
    }else if ([view isKindOfClass:[UIButton class]])
    {
        UIButton *btn = (UIButton *)view;
        btn.titleLabel.font = [UIFont fontWithName:fontFamily size:[[btn.titleLabel font] pointSize]];
    }else if ([view isKindOfClass:[UITextField class]])
    {
        UITextField *textfield = (UITextField *)view;
        [textfield setFont:[UIFont fontWithName:fontFamily size:[[textfield font] pointSize]]];
    }
    
    if (isSubViews)
    {
        for (UIView *sview in view.subviews)
        {
            [self setFontFamily:fontFamily forView:sview andSubViews:YES];
        }
    }
}

-(void)getActivityList{
    [NSThread detachNewThreadSelector:@selector(threadStartAnimating:) toTarget:self withObject:nil];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSString *urlString = [[NSString alloc]initWithFormat:@"http://www.mobiwebcode.com/communication/ActivityDetail.php?userid=%@",[prefs objectForKey:@"loggedin"]];
    NSData *mydata = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    NSString *content = [[NSString alloc]  initWithBytes:[mydata bytes]
                                                  length:[mydata length] encoding: NSUTF8StringEncoding];
    NSError *error;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:mydata options:0 error:&error];
    if(![content isEqualToString:@"no"]){
    NSArray *activityArray=[[json objectForKey:@"activitydetail"] objectForKey:@"activity"];
    for (int count=0; count<[activityArray count]; count++) {
        NSDictionary *activityData=[activityArray objectAtIndex:count];
        ActivityVO *avo=[[ActivityVO alloc] init];
        avo.userimage=[[NSString alloc] init];
        avo.username=[[NSString alloc] init];
        avo.message=[[NSString alloc] init];
        avo.date=[[NSString alloc] init];
        if ([activityData objectForKey:@"message"] != [NSNull null])
            avo.userimage=[activityData objectForKey:@"userimage"];
        avo.username=[activityData objectForKey:@"username"];
        avo.message=[activityData objectForKey:@"message"];
        avo.date=[activityData objectForKey:@"date"];
        [activityDetailsArray addObject:avo];
    }
    }
    [tableViewMain reloadData];
    [activityIndicator stopAnimating];
}

- (void) threadStartAnimating:(id)data {
    [activityIndicator startAnimating];
    activityIndicator.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.0);
    [self.view addSubview: activityIndicator];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    activityDetailsArray=[[NSMutableArray alloc] init];
    
    [activityIndicator stopAnimating];
    // Do any additional setup after loading the view from its nib.
    [self setFontFamily:@"Gotham Narrow" forView:self.view andSubViews:YES];
    appDelegate=[[UIApplication sharedApplication] delegate];
    appDelegate.selectedMenuItem=@"ACTIVITY";
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [titleLabel setFrame:CGRectMake(30, 0, 110, 35)];
    [titleLabel setText:@"ACTIVITY"];
    
    titleLabel.font =[UIFont systemFontOfSize:18];
    self.navigationItem.titleView = titleLabel;
    appDelegate=[[UIApplication sharedApplication] delegate];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navBar.png"]];
    self.navigationController.navigationBar.translucent = NO;
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"feedtablebg.png"]];
    SWRevealViewController *revealController = [self revealViewController];
    
    [revealController panGestureRecognizer];
    [revealController tapGestureRecognizer];
    
    UIBarButtonItem *revealButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"reveal-icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                                         style:UIBarButtonItemStylePlain target:revealController action:@selector(revealToggle:)];
    
    self.navigationItem.leftBarButtonItem = revealButtonItem;
    
        
    [self getActivityList];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma marl - UITableView Data Source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [activityDetailsArray count];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    ActivityVO *avo=[activityDetailsArray objectAtIndex:indexPath.row];
    AsyncImageView *userImageView;
    UILabel *messageLabel,*timeLabel,*usernameLabel;
    if (nil == cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
        cell.textLabel.textColor=[UIColor whiteColor];
        userImageView=[[AsyncImageView alloc] initWithFrame:CGRectMake(5, 5, 35, 35)];
        [userImageView setBackgroundColor:[UIColor clearColor]];
        userImageView.tag=1;
        userImageView.backgroundColor=[UIColor clearColor];
        usernameLabel=[[UILabel alloc] initWithFrame:CGRectMake(50, 5, 200, 20)];
        usernameLabel.tag=2;
        messageLabel=[[UILabel alloc] initWithFrame:CGRectMake(50, 25, 180, 25)];
        messageLabel.tag=3;
        timeLabel=[[UILabel alloc] initWithFrame:CGRectMake(235, 5, 100, 45)];
        timeLabel.tag=4;
        usernameLabel.font = [UIFont fontWithName:@"Gotham Narrow" size:12];
        usernameLabel.textColor=[UIColor blackColor];
        messageLabel.font = [UIFont fontWithName:@"Gotham Narrow" size:12];
        messageLabel.textColor=[UIColor blackColor];
        timeLabel.font = [UIFont fontWithName:@"Gotham Narrow" size:12];
        timeLabel.textColor=[UIColor blackColor];
        
        [cell.contentView addSubview:userImageView];
        [cell.contentView addSubview:usernameLabel];
        [cell.contentView addSubview:messageLabel];
        [cell.contentView addSubview:timeLabel];
    }
    tableView.backgroundColor=[UIColor clearColor];
    dispatch_async(dispatch_get_main_queue(), ^{
        //Your main thread code goes in here
        NSLog(@"Im on the main thread");
        
        
        AsyncImageView *userImageView= (id)[cell.contentView viewWithTag:1];
        UILabel *usernameLabel = (id)[cell.contentView viewWithTag:2];
        UILabel *messageLabel = (id)[cell.contentView viewWithTag:3];
        UILabel *timeLabel = (id)[cell.contentView viewWithTag:4];
        
        [userImageView loadImageFromURL:[NSURL URLWithString:avo.userimage]];
        
        usernameLabel.text=avo.username;
        
        messageLabel.text=avo.message;
        
        timeLabel.text=avo.date;
        
    });
    
    return cell;
}

@end
