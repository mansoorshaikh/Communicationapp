//
//  MediaVO.h
//  Communication
//
//  Created by arvind on 4/1/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MediaVO : NSObject
@property(nonatomic,retain) NSString *mediaid,*medianame,*mediadate,*mediapath,*mediapicture,*youtubevideo;
@end
