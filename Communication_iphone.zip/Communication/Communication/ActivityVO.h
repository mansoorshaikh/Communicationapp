//
//  ActivityVO.h
//  Communication
//
//  Created by mansoor shaikh on 27/03/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ActivityVO : NSObject
@property(nonatomic,retain) NSString *userimage,*username,*message,*date;
@end
