//
//  ImageVO.h
//  Communication
//
//  Created by arvind on 3/31/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageVO : NSObject
@property(nonatomic,retain) NSString *imageid,*imagepath;

@end
