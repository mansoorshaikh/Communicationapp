//
//  CalenderVO.h
//  Communication
//
//  Created by arvind on 3/30/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalenderVO : NSObject
@property(nonatomic,retain) NSString *calendareventid,*calendareventdate,*calendareventtime,*calendareventtext,*eventsDate;

@end
