package com.mobiwebcode.Communication;

import java.util.ArrayList;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class FeedDetails extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout,logOutRelativeLayout;
	FrameLayout mainFrameLayout;
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	TextView feedtitleTextView, feeddateTextView, feeddetailsTextView;
	NormalSmartImageView feeddetailsImageview;

	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	public static FeedVO selectedFeedVO = new FeedVO();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feeddetails);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		Typeface font_bold = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Black.otf");
		feedtitleTextView = (TextView) findViewById(R.id.feedtitleTextView);
		feedtitleTextView.setText(selectedFeedVO.feedtext);
		
		feeddateTextView = (TextView) findViewById(R.id.feeddateTextView);
		feeddateTextView.setText(selectedFeedVO.time);
		
		feeddetailsTextView = (TextView) findViewById(R.id.feeddetailsTextView);
		feeddetailsTextView.setText(selectedFeedVO.feeddescription);
		
		feeddetailsImageview = (NormalSmartImageView)findViewById(R.id.feeddetailsImageview);
		feeddetailsImageview.setImageUrl(selectedFeedVO.feedimage);

		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		feedRelativeLayout.setBackgroundResource(R.drawable.tablecellselected);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout)findViewById(R.id.logOutRelativeLayout);
		mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLayout);

		LoginActivity.applyFonts(mainFrameLayout, font);

		feedtitleTextView.setTypeface(font_bold);
		feeddateTextView.setTypeface(font);
		feeddateTextView.setTextSize(8);
		feeddetailsTextView.setTypeface(font);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(FeedDetails.this, HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(FeedDetails.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(FeedDetails.this, MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(FeedDetails.this, MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(FeedDetails.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(FeedDetails.this, CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(FeedDetails.this, SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = FeedDetails.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();
			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(FeedDetails.this,
					LoginActivity.class);
			startActivity(intent);
		}
	}

	public void finishActivity(View view) {
		finish();
	}
}
