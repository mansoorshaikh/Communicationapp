package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class HomeActivity extends Activity {

	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout, logOutRelativeLayout;

	private LinearLayout slidingPanel;
	Button events, date, survey, msg;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	ListView listview;
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	ArrayList<ActivityVO> activitylist = new ArrayList<ActivityVO>();
	FrameLayout mainFrameLayout;
	public static String responseString = "",userimage="",username="";
	ProgressDialog mProgressDialog;
	TextView menuTextView,userName;
	NormalSmartImageView userImage;
	

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		msg = (Button) findViewById(R.id.msg);
		events = (Button) findViewById(R.id.events);
		survey = (Button) findViewById(R.id.survey);
		date = (Button) findViewById(R.id.date);
		menuTextView = (TextView) findViewById(R.id.menuTextView);
	
		date.setText(android.text.format.DateFormat.format("dd MMMM",
				new java.util.Date()));

		new myTask_activityDetails_call().execute();

		Constants.MENU_ITEM_SELECTED = "HOME";
		listview = (ListView) findViewById(R.id.list);
		listview.setCacheColorHint(Color.TRANSPARENT);

		mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLyout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		LoginActivity.applyFonts(mainFrameLayout, font);
		TextView menuTextView = (TextView) findViewById(R.id.menuTextView);
		menuTextView.setTypeface(font);
		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		homeRelativeLayout.setBackgroundResource(R.drawable.tablecellselected);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout) findViewById(R.id.logOutRelativeLayout);
		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
	}

	public void handleOnClick(View view) {
		if (view.getId() == R.id.msg) {
			Intent msg = new Intent(HomeActivity.this, Activity_Activity.class);
			startActivity(msg);
		} else if (view.getId() == R.id.survey) {
			Intent survey = new Intent(HomeActivity.this, FeedsActivity.class);
			startActivity(survey);
		} else if (view.getId() == R.id.events) {
			Intent events = new Intent(HomeActivity.this,
					CalendarActivity.class);
			startActivity(events);
		} else if (view.getId() == R.id.date) {
			Intent date = new Intent(HomeActivity.this, CalendarActivity.class);
			startActivity(date);
		}

	}

	// DownloadJSON AsyncTask for Activity_details
	class myTask_activityDetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient
						.execute(new HttpGet(
								"http://www.mobiwebcode.com/communication/ActivityDetail.php"));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				JSONObject jso = new JSONObject(responseString);
				JSONArray activityArray = jso.getJSONObject("activitydetail")
						.getJSONArray("activity");
				for (int i = 0; i < activityArray.length(); i++) {

					JSONObject activityObject = (JSONObject) activityArray
							.get(i);
					ActivityVO aVo = new ActivityVO();
					if (!activityObject.isNull("userimage"))
						aVo.userimage = activityObject.getString("userimage");
					if (!activityObject.isNull("username"))
						aVo.username = activityObject.getString("username");
					if (!activityObject.isNull("message"))
						aVo.activitydetails = activityObject
								.getString("message");
					if (!activityObject.isNull("date"))
						aVo.date = activityObject.getString("date");
					activitylist.add(aVo);

				}
				final ListArrayAdapterActivity adapter = new ListArrayAdapterActivity(
						HomeActivity.this, activitylist);
				listview.setAdapter(adapter);
				if (mProgressDialog != null)
					mProgressDialog.dismiss();
				new myTask_homepagedetails_call().execute();

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

	}

	class myTask_homepagedetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient.execute(new HttpGet(
						"http://www.mobiwebcode.com/communication/HomepageDetail.php?userid="
								+ LoginActivity.userid));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				JSONObject jso = new JSONObject(responseString);
				JSONObject jso_data = jso.getJSONObject("homepagedetails")
						.getJSONObject("homepage");

				if (!jso_data.isNull("messages"))
					msg.setText(jso_data.getString("messages") + "\n"
							+ "NEW MESSAGES");
				if (!jso_data.isNull("survey"))
					survey.setText(jso_data.getString("survey") + "\n"
							+ "NEW SURVEYS");
				if (!jso_data.isNull("events"))
					events.setText(jso_data.getString("events") + "\n"
							+ "Events Today");
				if (!jso_data.isNull("username")){
					username=jso_data.getString("username");
					menuTextView
							.setText("Hi " + jso_data.getString("username"));
				}
				if (!jso_data.isNull("userimage")){
					userimage=jso_data.getString("userimage").replace("\\/", "/");
				}
				userImage = (NormalSmartImageView)findViewById(R.id.icon);
				userImage.setImageUrl(userimage);
				userName = (TextView)findViewById(R.id.homeusername);
				userName.setText(username);
				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(HomeActivity.this, FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(HomeActivity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(HomeActivity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(HomeActivity.this, MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(HomeActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(HomeActivity.this, CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(HomeActivity.this,
					SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = HomeActivity.this.getSharedPreferences(
					"myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();

			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
			startActivity(intent);
		}
	}

	@Override
	public void onBackPressed() {

	}
}
