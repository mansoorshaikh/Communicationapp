package com.mobiwebcode.Communication;

import android.database.sqlite.SQLiteDatabase;

public class Constants {
	public static SQLiteDatabase CommunicationDatabase;
	public static String MENU_ITEM_SELECTED = "";
}
