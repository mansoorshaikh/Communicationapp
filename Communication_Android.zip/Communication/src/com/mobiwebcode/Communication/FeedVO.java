package com.mobiwebcode.Communication;

public class FeedVO {
	public String feedid = "", feedtype = "", feedtext = "", time = "",
			feeddescription = "", feedimage = "",feedformat = "",response = "";

}
