package com.mobiwebcode.Communication;

public class CalendarVO {

	public String calendareventid = "", calendareventdate = "",
			calendareventtime = "", calendareventtext = "";

}
