package com.mobiwebcode.Communication;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class ListArrayAdapterActivity extends ArrayAdapter<ActivityVO> {

	private final Context context;
	private final ArrayList<ActivityVO> values;
	public static AlertDialog.Builder builderSingle;

	public ListArrayAdapterActivity(Context context, ArrayList<ActivityVO> values) {
		super(context, R.layout.listview_item_row, values);
		this.context = context;
		this.values = values;
	}

	public void closeDialogue() {

	}

	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View rowView = inflater.inflate(R.layout.listview_item_row, parent,
				false);
		Typeface font_bold = Typeface.createFromAsset(context.getAssets(),
				"GothamNarrow-Black.otf");
		Typeface font = Typeface.createFromAsset(context.getAssets(),
				"GothamNarrow-Light.otf");

		if (Constants.MENU_ITEM_SELECTED.equals("CALENDAR")) {
			
			rowView = inflater.inflate(R.layout.listview_item_row_calendar,
					parent, false);
			ActivityVO aVo = values.get(position);
			TextView time = (TextView) rowView
					.findViewById(R.id.secondLine);
			time.setTextColor(Color.GRAY);
		//	time.setTypeface(font_bold);
			time.setText(aVo.time);
			TextView message = (TextView) rowView
					.findViewById(R.id.thirdline);
			message.setTypeface(font_bold);
			message.setTextColor(Color.GRAY);
			message.setText(aVo.message);
		} else {
			rowView = inflater.inflate(R.layout.listview_item_row, parent,
					false);
			ActivityVO aVo = values.get(position);
			TextView textView1 = (TextView) rowView
					.findViewById(R.id.secondLine);
		//	textView1.setTypeface(font_bold);
			TextView textView2 = (TextView) rowView
					.findViewById(R.id.thirdline);
			textView2.setTypeface(font_bold);
			TextView timelineView2 = (TextView) rowView
					.findViewById(R.id.timeline);
			timelineView2.setTypeface(font_bold);
			timelineView2.setTextSize(10);
			NormalSmartImageView imageView = (NormalSmartImageView) rowView.findViewById(R.id.icon);
			if (Constants.MENU_ITEM_SELECTED.equals("FEED")) {
				timelineView2.setVisibility(View.GONE);
				textView1.setText(aVo.date);
				textView2.setText(aVo.username);
				textView1.setTextSize(10);
			
				if (position == 3) {
					textView2.setText(aVo.activitydetails);
				}
			} else if (Constants.MENU_ITEM_SELECTED.equals("HOME")) {
				textView1.setText(aVo.activitydetails);
				textView2.setText(aVo.username);
				timelineView2.setText(aVo.date);
			
			} else if (Constants.MENU_ITEM_SELECTED.equals("ACTIVITY")) {
				textView1.setText(aVo.activitydetails);
				textView2.setText(aVo.username);
				timelineView2.setText(aVo.date);
			}
			imageView.setImageUrl(aVo.userimage);
		}
		// change the icon for Windows and iPhone
		return rowView;
	}
}
