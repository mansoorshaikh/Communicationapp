package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class FeedsActivity extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout, logOutRelativeLayout;
	public static LinearLayout feedlinearlayout;
	String responseString = "";
	String feeds = "";
	Activity mcontext = null;
	ViewGroup parent = null;
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	ListView listview;
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	ArrayList<FeedTypeVO> feedlist = new ArrayList<FeedTypeVO>();
	ArrayList<FeedVO> feedDetailsList = new ArrayList<FeedVO>();
	ArrayList<Button> feedbuttonlist = new ArrayList<Button>();
	private ProgressDialog mProgressDialog;
	TextView userName;
	NormalSmartImageView userImage;
	

	SegmentedRadioGroup segmentText;
	SegmentedRadioGroup segmentImg;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feed);
		
		userImage = (NormalSmartImageView)findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView)findViewById(R.id.feedUsername);
		userName.setText(HomeActivity.username);

		// segmentText = (SegmentedRadioGroup) findViewById(R.id.segment_text);
		// segmentText.setOnCheckedChangeListener(this);
		//

		Constants.MENU_ITEM_SELECTED = "FEED";
		listview = (ListView) findViewById(R.id.list);
		listview.setCacheColorHint(Color.TRANSPARENT);

		new myTask_feedActivity_call().execute();

		FrameLayout mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLayout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		LoginActivity.applyFonts(mainFrameLayout, font);

		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		feedRelativeLayout.setBackgroundResource(R.drawable.tablecellselected);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		feedlinearlayout = (LinearLayout) findViewById(R.id.feedlinearlayout);
		logOutRelativeLayout = (RelativeLayout) findViewById(R.id.logOutRelativeLayout);

		// final ListArrayAdapter adapter = new ListArrayAdapter(this,
		// menuArrayList);
		// listview.setAdapter(adapter);

		listview.setOnItemClickListener(new OnItemClickListener() {
			

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				FeedVO fvo = feedDetailsList.get(arg2);
				if ( fvo.feedformat.equals("Question")) {
					Intent intent = new Intent(FeedsActivity.this,
							FeedSurveyActivity.class);
					FeedSurveyActivity.selectedFeedVO=feedDetailsList.get(arg2);
					startActivity(intent);
				} else {
					Intent intent = new Intent(FeedsActivity.this,
							FeedDetails.class);
					FeedDetails.selectedFeedVO=feedDetailsList.get(arg2);
					startActivity(intent);
				}
			}
		});

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
	}

	// DownloadJSON AsyncTask for feedActivity
	class myTask_feedActivity_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				
				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/feedtypes.php"));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				if(!responseString.equals("no")){
				JSONObject jso = new JSONObject(responseString);
				JSONArray feedArray = jso.getJSONObject("feeddetail")
						.getJSONArray("feed");
				for (int i = 0; i < feedArray.length(); i++) {

					JSONObject feedObject = (JSONObject) feedArray.get(i);
					FeedTypeVO fVo = new FeedTypeVO();

					if (!feedObject.isNull("feedid"))
						fVo.feedid = feedObject.getString("feedid");
					if (!feedObject.isNull("feedtype"))
						fVo.feedtype = feedObject.getString("feedtype");
					feedlist.add(fVo);

				}
				}
				int counter = 0;
				LinearLayout LL = new LinearLayout(FeedsActivity.this);
				LayoutParams LLParams = new LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
				LL.setLayoutParams(LLParams);
				LL.setOrientation(LinearLayout.HORIZONTAL);

				Display display = getWindowManager().getDefaultDisplay();
				int width = display.getWidth();
				for (int count = 0; count < feedlist.size(); count++) {
					FeedTypeVO fVo = feedlist.get(count);
					final Button feedbtn = new Button(FeedsActivity.this);
					feedbtn.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							selectedButton(feedbtn);
						}
					});
					feedbtn.setLayoutParams(new LayoutParams(width / 4,
							LayoutParams.WRAP_CONTENT));
					feedbtn.setText(fVo.feedtype);
					feedbtn.setId(count);
					LL.addView(feedbtn);
					feedbuttonlist.add(feedbtn);

					counter++;
					if (counter == 4 || count == feedlist.size() - 1) {
						feedlinearlayout.addView(LL);
						LL = new LinearLayout(FeedsActivity.this);
						LLParams = new LayoutParams(LayoutParams.MATCH_PARENT,
								LayoutParams.WRAP_CONTENT);
						LL.setLayoutParams(LLParams);
						counter = 0;
					}

					if (mProgressDialog != null)
						mProgressDialog.dismiss();
					new myTask_feedDetailsList_call().execute();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	// selected button in feedDetails
	void selectedButton(Button feedbtn) {

		for (int i = 0; i < feedbuttonlist.size(); i++) {
			Button btn = (Button) feedbuttonlist.get(i);
			btn.getBackground().setAlpha(100);
		}
		feedbtn.getBackground().setAlpha(30);
		feeds=feedbtn.getText().toString();
		new myTask_feedDetailsList_call().execute();

	}

	// DownloadJSON AsyncTask for feedDetails
	class myTask_feedDetailsList_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				if (feeds == "") {
					feeds = ((FeedTypeVO) feedlist.get(0)).feedtype;
				}

				response = httpclient
						.execute(new HttpGet(
								"http://www.mobiwebcode.com/communication/feedlist.php?feedtype="+feeds));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				if(!responseString.equals("no")){
				JSONObject jso = new JSONObject(responseString);
				JSONArray feedArray = jso.getJSONObject("feeddetails")
						.getJSONArray("feed");
				feedDetailsList.clear();
				for (int i = 0; i < feedArray.length(); i++) {

					JSONObject feedObject = (JSONObject) feedArray.get(i);
					FeedVO fvo = new FeedVO();
					if (!feedObject.isNull("feedid"))
						fvo.feedid = feedObject.getString("feedid");
					if (!feedObject.isNull("feedtype"))
						fvo.feedtype = feedObject.getString("feedtype");
					if (!feedObject.isNull("feedtext"))
						fvo.feedtext = feedObject.getString("feedtext");
					if (!feedObject.isNull("time"))
						fvo.time = feedObject.getString("time");
					if (!feedObject.isNull("feeddescription"))
						fvo.feeddescription = feedObject
								.getString("feeddescription");
					if (!feedObject.isNull("feedimage"))
						fvo.feedimage = feedObject.getString("feedimage");
					if (!feedObject.isNull("feedformat"))
						fvo.feedformat = feedObject.getString("feedformat");
					feedDetailsList.add(fvo);

				}
				}
				final ListArrayAdapterFeed adapter = new ListArrayAdapterFeed(
						FeedsActivity.this, feedDetailsList);
				listview.setAdapter(adapter);

				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(FeedsActivity.this, HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(FeedsActivity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(FeedsActivity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(FeedsActivity.this, MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(FeedsActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(FeedsActivity.this, CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(FeedsActivity.this,
					SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = FeedsActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();
			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(FeedsActivity.this, LoginActivity.class);
			startActivity(intent);
		}
	}

	public void onCheckedChanged(RadioGroup group, int checkedId) {
		if (group == segmentText) {
			if (checkedId == R.id.button_one) {
			} else if (checkedId == R.id.button_two) {
			} else if (checkedId == R.id.button_three) {
			}
		}
	}

	@Override
	public void onBackPressed() {

	}
}