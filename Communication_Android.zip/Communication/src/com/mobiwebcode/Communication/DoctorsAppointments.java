package com.mobiwebcode.Communication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.mobiwebcode.Communication.Calendar.CalendarAdapter;

public class DoctorsAppointments extends Activity {

	public GregorianCalendar month, itemmonth;// calendar instances.
	String fromDoctorsAppointment = "";
	public CalendarAdapter adapter;
	public Handler handler;
	public ArrayList<String> items;
	ArrayList<String> event;
	ArrayAdapter<String> arrayAdapter = null;
	LinearLayout rLayout;
	ArrayList<String> date;
	ArrayList<String> desc;
	ListView lv;

	private int hour;
	private int minute;

	static final int TIME_DIALOG_ID = 999;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.calendar);

		arrayAdapter = new ArrayAdapter<String>(DoctorsAppointments.this,
				android.R.layout.select_dialog_singlechoice);

		arrayAdapter = new ArrayAdapter<String>(DoctorsAppointments.this,
				android.R.layout.select_dialog_singlechoice);
		arrayAdapter.add("John Doe");
		arrayAdapter.add("John Doe");
		arrayAdapter.add("John Doe");
		arrayAdapter.add("John Doe");
		arrayAdapter.add("John Doe");

		lv = (ListView) findViewById(R.id.list);
		final Calendar c = Calendar.getInstance();
		hour = c.get(Calendar.HOUR_OF_DAY);
		minute = c.get(Calendar.MINUTE);
		String[] values = new String[] { "Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM",
				"Dr. John Doe on 14th Jan 20: 30 PM" };

		ArrayAdapter<String> adapter_ = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, values);

		lv.setAdapter(adapter_);

		Locale.setDefault(Locale.US);

		month = (GregorianCalendar) GregorianCalendar.getInstance();
		itemmonth = (GregorianCalendar) month.clone();

		items = new ArrayList<String>();

		adapter = new CalendarAdapter(this, month);

		GridView gridview = (GridView) findViewById(R.id.gridview);
		gridview.setAdapter(adapter);

		handler = new Handler();
		handler.post(calendarUpdater);

		TextView title = (TextView) findViewById(R.id.title);
		title.setText(android.text.format.DateFormat.format("MMMM yyyy", month));

		RelativeLayout previous = (RelativeLayout) findViewById(R.id.previous);

		previous.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setPreviousMonth();
				refreshCalendar();
			}
		});

		RelativeLayout next = (RelativeLayout) findViewById(R.id.next);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setNextMonth();
				refreshCalendar();

			}
		});

		gridview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View v,
					int position, long id) {
				desc = new ArrayList<String>();
				date = new ArrayList<String>();
				((CalendarAdapter) parent.getAdapter()).setSelected(v);
				String selectedGridDate = CalendarAdapter.dayString
						.get(position);
				String[] separatedTime = selectedGridDate.split("-");
				String gridvalueString = separatedTime[2].replaceFirst("^0*",
						"");// taking last part of date. ie; 2 from 2012-12-02.
				int gridvalue = Integer.parseInt(gridvalueString);
				if ((gridvalue > 10) && (position < 8)) {
					setPreviousMonth();
					refreshCalendar();
				} else if ((gridvalue < 7) && (position > 28)) {
					setNextMonth();
					refreshCalendar();
				}
				((CalendarAdapter) parent.getAdapter()).setSelected(v);
				fromDoctorsAppointment = "yes";
				showDialog();
			}
		});
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case TIME_DIALOG_ID:
			// set time picker as current time
			TimePickerDialog d = new TimePickerDialog(DoctorsAppointments.this,
					timePickerListener, hour, minute, false);
			d.setTitle("Appointment Time");
			return d;

		}
		return null;
	}

	private TimePickerDialog.OnTimeSetListener timePickerListener = new TimePickerDialog.OnTimeSetListener() {
		public void onTimeSet(TimePicker view, int selectedHour,
				int selectedMinute) {
			hour = selectedHour;
			minute = selectedMinute;
		}
	};

	void showDialog() {
		AlertDialog.Builder builderSingle = new AlertDialog.Builder(
				DoctorsAppointments.this);
		builderSingle.setIcon(R.drawable.ic_launcher);
		builderSingle.setTitle("Select Doctor");
		builderSingle.setNegativeButton("cancel",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});

		builderSingle.setAdapter(arrayAdapter,
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						showDialog(TIME_DIALOG_ID);
					}
				});
		builderSingle.show();
	}

	protected void setNextMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMaximum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) + 1),
					month.getActualMinimum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) + 1);
		}

	}

	protected void setPreviousMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMinimum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) - 1),
					month.getActualMaximum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) - 1);
		}

	}

	protected void showToast(String string) {
		Toast.makeText(this, string, Toast.LENGTH_SHORT).show();

	}

	public void refreshCalendar() {
		TextView title = (TextView) findViewById(R.id.title);

		adapter.refreshDays();
		adapter.notifyDataSetChanged();
		handler.post(calendarUpdater); // generate some calendar items

		title.setText(android.text.format.DateFormat.format("MMMM yyyy", month));
	}

	public Runnable calendarUpdater = new Runnable() {

		@Override
		public void run() {
			items.clear();

			// Print dates of the current week
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
			String itemvalue;
			// event = Utility.readCalendarEvent(CalendarView.this);

			for (int i = 0; i < 5; i++) {
				itemvalue = "2014";
				itemmonth.add(GregorianCalendar.DATE, 1);
				items.add("Test");
			}
			adapter.setItems(items);
			adapter.notifyDataSetChanged();
		}
	};
}
