package com.mobiwebcode.Communication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class CreateActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);		
		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("message/rfc822");
		i.putExtra(Intent.EXTRA_EMAIL,
				new String[] { "neffchip@gmail.com" });
		i.putExtra(Intent.EXTRA_SUBJECT, "Send Message");
		i.putExtra(Intent.EXTRA_TEXT,"");
		try {
			CreateActivity.this.startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
			Toast.makeText(CreateActivity.this, "There are no email clients installed.",
					Toast.LENGTH_SHORT).show();
		}
	}
@Override
	public void onBackPressed() {
		super.onBackPressed();
		Intent intent = new Intent(CreateActivity.this, HomeActivity.class);
		startActivity(intent);
	
	}
}
