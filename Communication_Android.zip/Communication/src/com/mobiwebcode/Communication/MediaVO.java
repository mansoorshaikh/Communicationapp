package com.mobiwebcode.Communication;

public class MediaVO {
	public String mediaId = "",mediaName = "",mediaDate = "",mediaPath = "",mediaPicture = "",youtubevideo = "";

}
