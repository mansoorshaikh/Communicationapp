package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mobiwebcode.Communication.Calendar.CalendarAdapter;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class CalendarActivity extends Activity {
	public GregorianCalendar month, itemmonth;// calendar instances.
	public CalendarAdapter adapter;
	public Handler handler;
	String selectedGridDate;
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	ArrayList<CalendarVO> calendarlist = new ArrayList<CalendarVO>();
	String responseString = "";
	public ArrayList<String> items;
	ArrayList<String> event;
	ArrayAdapter<String> arrayAdapter = null;
	LinearLayout rLayout;
	ArrayList<String> date;
	ArrayList<String> desc;
	ListView lv;

	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout,logOutRelativeLayout;

	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	ListView listview;
	private ProgressDialog mProgressDialog;
	FrameLayout mainFrameLayout;
	TextView userName;
	NormalSmartImageView userImage;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.calendarlayout);
		Constants.MENU_ITEM_SELECTED = "CALENDAR";
		
		userImage = (NormalSmartImageView)findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView)findViewById(R.id.calendarUsername);
		userName.setText(HomeActivity.username);
		
		listview = (ListView) findViewById(R.id.list);
		listview.setCacheColorHint(Color.TRANSPARENT);
		mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLayout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		LoginActivity.applyFonts(mainFrameLayout, font);
		
			new myTask_calenderDetails_call().execute();
		

		// final ListArrayAdapter adapter_list = new ListArrayAdapter(this,
		// menuArrayList);
		// listview.setAdapter(adapter_list);

		month = (GregorianCalendar) GregorianCalendar.getInstance();
		itemmonth = (GregorianCalendar) month.clone();

		items = new ArrayList<String>();

		adapter = new CalendarAdapter(this, month);

		GridView gridview = (GridView) findViewById(R.id.gridview);
		gridview.setAdapter(adapter);

		handler = new Handler();
		handler.post(calendarUpdater);

		TextView title = (TextView) findViewById(R.id.title);
		title.setText(android.text.format.DateFormat.format("MMMM yyyy", month));

		RelativeLayout previous = (RelativeLayout) findViewById(R.id.previous);

		previous.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setPreviousMonth();
				refreshCalendar();
			}
		});

		RelativeLayout next = (RelativeLayout) findViewById(R.id.next);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setNextMonth();
				refreshCalendar();

			}
		});

		gridview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View v,
					int position, long id) {
				desc = new ArrayList<String>();
				date = new ArrayList<String>();
				((CalendarAdapter) parent.getAdapter()).setSelected(v);
				selectedGridDate = CalendarAdapter.dayString
						.get(position);
				String[] separatedTime = selectedGridDate.split("/");
				String gridvalueString = separatedTime[2].replaceFirst("^0*",
						"");// taking last part of date. ie; 2 from 2012-12-02.
				int gridvalue = Integer.parseInt(gridvalueString);
				if ((gridvalue > 10) && (position < 8)) {
					setPreviousMonth();
					refreshCalendar();
				} else if ((gridvalue < 7) && (position > 28)) {
					setNextMonth();
					refreshCalendar();
				}
				((CalendarAdapter) parent.getAdapter()).setSelected(v);
				new myTask_calenderDetails_call().execute();
			}
		});

		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		calendarRelativeLayout
				.setBackgroundResource(R.drawable.tablecellselected);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout)findViewById(R.id.logOutRelativeLayout);
		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
	}

	protected void setNextMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMaximum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) + 1),
					month.getActualMinimum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) + 1);
		}

	}

	protected void setPreviousMonth() {
		if (month.get(GregorianCalendar.MONTH) == month
				.getActualMinimum(GregorianCalendar.MONTH)) {
			month.set((month.get(GregorianCalendar.YEAR) - 1),
					month.getActualMaximum(GregorianCalendar.MONTH), 1);
		} else {
			month.set(GregorianCalendar.MONTH,
					month.get(GregorianCalendar.MONTH) - 1);
		}

	}

	public void refreshCalendar() {
		TextView title = (TextView) findViewById(R.id.title);

		adapter.refreshDays();
		adapter.notifyDataSetChanged();
		handler.post(calendarUpdater); // generate some calendar items

		title.setText(android.text.format.DateFormat.format("MMMM yyyy", month));
	}

	public Runnable calendarUpdater = new Runnable() {
		@Override
		public void run() {
			items.clear();

			// Print dates of the current week
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
			String itemvalue;
			// event = Utility.readCalendarEvent(CalendarView.this);

			for (int i = 0; i < 5; i++) {
				itemvalue = "2014";
				itemmonth.add(GregorianCalendar.DATE, 1);
				items.add("Test");
			}
			adapter.setItems(items);
			adapter.notifyDataSetChanged();
		}
	};

	// DownloadJSON AsyncTask for calenderDetails
	class myTask_calenderDetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				JSONObject jso = new JSONObject();
				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/calendarevents.php?currentdate="+selectedGridDate));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				calendarlist=new ArrayList<CalendarVO>();
				if(!responseString.equals("no")){
				JSONObject jso = new JSONObject(responseString);
				JSONArray calendarArray=null;
				try {
					 calendarArray = jso.getJSONObject(
							"calendareventdetail").getJSONArray("calendarevent");
				} catch (Exception e) {
					// TODO: handle exception
					calendarArray=new JSONArray();
					calendarArray.put(jso.getJSONObject(
							"calendareventdetail").getJSONObject("calendarevent"));
				}
				
				for (int i = 0; i < calendarArray.length(); i++) {

					JSONObject calendarObject = (JSONObject) calendarArray
							.get(i);
					CalendarVO cVo = new CalendarVO();
					if (!calendarObject.isNull("calendareventid"))
						cVo.calendareventid = calendarObject.getString("calendareventid");
					if (!calendarObject.isNull("calendareventdate"))
						cVo.calendareventdate = calendarObject.getString("calendareventdate");
					if (!calendarObject.isNull("calendareventtime"))
						cVo.calendareventtime = calendarObject.getString("calendareventtime");
					if (!calendarObject.isNull("calendareventtext"))
						cVo.calendareventtext = calendarObject.getString("calendareventtext");

					calendarlist.add(cVo);

				}
				}
				final ListArrayAdapterCalendar adapter = new ListArrayAdapterCalendar(
						CalendarActivity.this, calendarlist);
				listview.setAdapter(adapter);

				if (mProgressDialog != null)
					mProgressDialog.dismiss();
				
			} catch (Exception e) {
				if (mProgressDialog != null)
					mProgressDialog.dismiss();
				
				// TODO: handle exception
			}

		}

	}
	
	


	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(CalendarActivity.this,
					HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(CalendarActivity.this,
					FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(CalendarActivity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(CalendarActivity.this,
					MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(CalendarActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(CalendarActivity.this,
					CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(CalendarActivity.this,
					SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = CalendarActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();
			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(CalendarActivity.this,
					LoginActivity.class);
			startActivity(intent);
		}
	}
	@Override
	public void onBackPressed() {
		
	}
}

