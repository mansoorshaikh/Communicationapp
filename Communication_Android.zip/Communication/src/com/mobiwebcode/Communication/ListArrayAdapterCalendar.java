package com.mobiwebcode.Communication;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class ListArrayAdapterCalendar  extends ArrayAdapter<CalendarVO> {
	private final Context context;
	private final ArrayList<CalendarVO> values;
	public static AlertDialog.Builder builderSingle;

	public  ListArrayAdapterCalendar(Context context,
			ArrayList<CalendarVO> values) {
		super(context, R.layout.listview_item_row, values);
		this.context = context;
		this.values = values;
	}

	public void closeDialogue() {

	}

	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View rowView = inflater.inflate(R.layout.listview_item_row, parent,
				false);
		Typeface font_bold = Typeface.createFromAsset(context.getAssets(),
				"GothamNarrow-Black.otf");
		Typeface font = Typeface.createFromAsset(context.getAssets(),
				"GothamNarrow-Light.otf");

		CalendarVO cVo = values.get(position);
		TextView textView1 = (TextView) rowView.findViewById(R.id.secondLine);
		textView1.setTextColor(Color.GRAY);
		TextView textView2 = (TextView) rowView.findViewById(R.id.thirdline);
		textView2.setTextColor(Color.GRAY);
		textView2.setTypeface(font_bold);
		
			textView1.setText(cVo.calendareventtime);
			textView2.setText(cVo.calendareventtext);
			
			textView1.setTextSize(10);

			if (position == 3) {
				textView2.setText(cVo.calendareventtext);

			} 
			
		
		// change the icon for Windows and iPhone
		return rowView;
	}


}
