package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class MediaActivity extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout, logOutRelativeLayout;
	LinearLayout mediaListRelativeLayout;
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
    private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	TextView userName;
	NormalSmartImageView userImage;
	VideoView videoView;
	private ImageView menuViewButton;
	String responseString = "";
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	private ProgressDialog mProgressDialog;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	FrameLayout mainFrameLayout;
	ArrayList<MediaVO> mediaList = new ArrayList<MediaVO>();

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();

			return mProgressDialog;

		default:
			return null;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.medialayout);
		Constants.MENU_ITEM_SELECTED = "MEDIA";
		
		userImage = (NormalSmartImageView)findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView)findViewById(R.id.mediaUsername);
		userName.setText(HomeActivity.username);
		
		mediaListRelativeLayout = (LinearLayout) findViewById(R.id.mediaRelativeLayout);
		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		mediaRelativeLayout.setBackgroundResource(R.drawable.tablecellselected);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout) findViewById(R.id.logOutRelativeLayout);

		mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLyout);
		Typeface font_bold = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Black.otf");
		LoginActivity.applyFonts(mainFrameLayout, font_bold);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		TextView menuTextView = (TextView) findViewById(R.id.menuTextView);
		menuTextView.setTypeface(font);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
		new myTask_getMedia_call().execute();
	}

	void fillMedia() {
		Typeface font_bold = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Black.otf");
		LoginActivity.applyFonts(mainFrameLayout, font_bold);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		
		LinearLayout mediaItemLayout = new LinearLayout(MediaActivity.this);
		Display mDisplay = MediaActivity.this.getWindowManager()
				.getDefaultDisplay();
		final int width = mDisplay.getWidth();
		mediaItemLayout.setOrientation(LinearLayout.HORIZONTAL);
		LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.WRAP_CONTENT);
		mediaItemLayout.setLayoutParams(params);

		int k = 0;
		for (int count = 0; count < mediaList.size(); count++) {
			final MediaVO mVo = mediaList.get(count);
			LinearLayout mediaContentsLayout = new LinearLayout(
					MediaActivity.this);
			mediaContentsLayout.setLayoutParams(new LayoutParams(width / 2,
					LayoutParams.FILL_PARENT));
			mediaContentsLayout.setOrientation(LinearLayout.VERTICAL);
			NormalSmartImageView mediaItemImage = new NormalSmartImageView(
					MediaActivity.this);
			mediaItemImage.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					 try {
							final Dialog dialog = new Dialog(MediaActivity.this);
							dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
							dialog.setContentView(R.layout.videoview);
							dialog.show();
							videoView = (VideoView) dialog
									.findViewById(R.id.VideoView);
							WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
									LayoutParams.WRAP_CONTENT,
									LayoutParams.WRAP_CONTENT);
							lp.copyFrom(dialog.getWindow().getAttributes());
							dialog.getWindow().setAttributes(lp);
					       
					        String link= (mVo.mediaPath.replace("\\/", "/"));
					       
					        MediaController mediaController = new MediaController(MediaActivity.this);
					        mediaController.setAnchorView(videoView);
					        Uri video = Uri.parse(link);
					        videoView.setMediaController(mediaController);
					        videoView.setVideoURI(video);
					        videoView.start();
					    } catch (Exception e) {
					        // TODO: handle exception
					       
					    }
				

				}
			});
			
			
			mediaItemImage.setImageUrl(mVo.mediaPicture.replace("\\/", "/"));
			mediaItemImage.setLayoutParams(new LayoutParams(
					LayoutParams.FILL_PARENT, 170));
			TextView mediaItemTextView = new TextView(MediaActivity.this);
			mediaItemTextView.setTypeface(font_bold);
			LayoutParams mediaItemLayoutParams = new LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			mediaItemLayoutParams.setMargins(5, 0, 0, 0);
			mediaItemTextView.setLayoutParams(mediaItemLayoutParams);
			mediaItemTextView.setTextSize(12);
			mediaItemTextView.setTextColor(Color.BLACK);
			TextView timeItemTextView = new TextView(MediaActivity.this);
			timeItemTextView.setTypeface(font);
			timeItemTextView.setLayoutParams(mediaItemLayoutParams);
			timeItemTextView.setTextColor(Color.BLACK);
			timeItemTextView.setTextSize(8);
			if (k == 0) {

				mediaItemTextView.setText("medianame");
				timeItemTextView.setText("mediadate");
				mediaContentsLayout.addView(mediaItemImage);
				mediaContentsLayout.addView(mediaItemTextView);
				mediaContentsLayout.addView(timeItemTextView);
				mediaItemLayout.addView(mediaContentsLayout);
				k = 1;
			} else if (k == 1) {

				mediaItemTextView.setText("mediapath");
				timeItemTextView.setText("mediadate");
				mediaContentsLayout.addView(mediaItemImage);
				mediaContentsLayout.addView(mediaItemTextView);
				mediaContentsLayout.addView(timeItemTextView);
				mediaItemLayout.addView(mediaContentsLayout);
				mediaListRelativeLayout.addView(mediaItemLayout);
				mediaItemLayout = new LinearLayout(MediaActivity.this);
				k = 0;
			}
		}

	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(MediaActivity.this, HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(MediaActivity.this, FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(MediaActivity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(MediaActivity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(MediaActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(MediaActivity.this, CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(MediaActivity.this,
					SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = MediaActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();

			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(MediaActivity.this, LoginActivity.class);
			startActivity(intent);
		}
	}

	// DownloadJSON AsyncTask for getMedia

	class myTask_getMedia_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/medialist.php"));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				if(!responseString.equals("no")){
				JSONObject jso = new JSONObject(responseString);
				JSONArray mediaArray = jso.getJSONObject("mediadetails")
						.getJSONArray("media");
				for (int i = 0; i < mediaArray.length(); i++) {

					JSONObject activityObject = (JSONObject) mediaArray.get(i);
					MediaVO mVo = new MediaVO();
					if (!activityObject.isNull("mediaid"))
						mVo.mediaId = activityObject.getString("mediaid");
					if (!activityObject.isNull("medianame"))
						mVo.mediaName = activityObject.getString("medianame");
					if (!activityObject.isNull("mediadate"))
						mVo.mediaDate = activityObject.getString("mediadate");
					if (!activityObject.isNull("mediapath"))
						mVo.mediaPath = activityObject.getString("mediapath");
					if (!activityObject.isNull("mediapicture"))
						mVo.mediaPicture = activityObject
								.getString("mediapicture");
					if (!activityObject.isNull("youtubevideo"))
						mVo.youtubevideo = activityObject
								.getString("youtubevideo");

					mediaList.add(mVo);

				}
				}
				fillMedia();
				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onBackPressed() {

	}
}
