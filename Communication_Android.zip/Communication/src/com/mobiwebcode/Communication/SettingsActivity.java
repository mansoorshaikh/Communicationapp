package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import com.mobiwebcode.Communication.LoginActivity.myTask_registerUser_call;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class SettingsActivity extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout, logOutRelativeLayout;
	Bitmap photo = null;
	public static String userid = "";
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	ListView listview;
	TextView messageNotificationTextView, calendarNotificationTextView;
	ImageButton userImageButton;
	Button saveButton;
	TextView userName;
	NormalSmartImageView userImage;

	EditText usernameEditText, titleEditText, genderEditText, companyEditText,
			aboutEditText, emailEditText, passwordEditText, phoneEditText;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	private ProgressDialog mProgressDialog;
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	String responseString = "";
	private static final int PICK_FROM_CAMERA = 1;
	private static final int PICK_FROM_FILE = 2;
	private Uri mImageCaptureUri;
	private String mPath = "";
	Button changepassword;
	String oldpassword, newpassword;
	Bitmap image;
	RadioButton radioSexButton;
	RadioButton maleRadioButton, femaleRadioButton;
	RadioGroup radioSexGroup;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();

			return mProgressDialog;

		default:
			return null;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);

		userImage = (NormalSmartImageView) findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView) findViewById(R.id.settingUsername);
		userName.setText(HomeActivity.username);

		Typeface font_bold = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Black.otf");

		maleRadioButton = (RadioButton) findViewById(R.id.male);
		femaleRadioButton = (RadioButton) findViewById(R.id.female);
		radioSexGroup = (RadioGroup) findViewById(R.id.gender);

		userImageButton = (ImageButton) findViewById(R.id.userImageButton);
		// userImageButton = (Button) findViewById(R.id.userImageButton);
		userImageButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showPictureDialogue();
			}
		});
		saveButton = (Button) findViewById(R.id.save);
		saveButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				final String email = emailEditText.getText().toString();
				final String password = passwordEditText.getText().toString();
				if (!isValidEmail(email)) {
					emailEditText.setError("Invalid Email");
					emailEditText.requestFocus();
				} else if (!isValidPassword(password)) {
					passwordEditText.setError("Invalid Password");
					passwordEditText.requestFocus();
				}
				if (isValidEmail(email) && isValidPassword(password)) {
					new myTask_saveUserDetails_call().execute();
				}

				// get selected radio button from radioGroup
				int selectedId = radioSexGroup.getCheckedRadioButtonId();
				// find the radiobutton by returned id
				radioSexButton = (RadioButton) findViewById(selectedId);
				radioSexButton.getText().toString();

				// new myTask_saveUserDetails_call().execute();
			}
		});
		changepassword = (Button) findViewById(R.id.changepassword);
		changepassword.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				LinearLayout linearLayout = new LinearLayout(
						SettingsActivity.this);
				linearLayout.setOrientation(LinearLayout.VERTICAL);

				AlertDialog.Builder builder = new AlertDialog.Builder(
						SettingsActivity.this);
				builder.setMessage("Change your password");
				builder.setView(linearLayout);
				final EditText oldPassword = new EditText(SettingsActivity.this);
				oldPassword.setHint("Old Password");

				linearLayout.addView(oldPassword);

				final EditText newPassword = new EditText(SettingsActivity.this);
				newPassword.setHint("New Password");

				linearLayout.addView(newPassword);

				linearLayout = new LinearLayout(SettingsActivity.this);

				builder.setCancelable(false);
				builder.setPositiveButton("Update",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								oldpassword = oldPassword.getText().toString();
								newpassword = newPassword.getText().toString();
								checkPassword(oldpassword, newpassword);

							}
						});
				builder.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								dialog.cancel();
							}
						});
				AlertDialog alert = builder.create();
				alert.show();

			}
		});

		usernameEditText = (EditText) findViewById(R.id.usernameEditText);
		titleEditText = (EditText) findViewById(R.id.titleEditText);

		companyEditText = (EditText) findViewById(R.id.companyEditText);
		aboutEditText = (EditText) findViewById(R.id.aboutEditText);
		emailEditText = (EditText) findViewById(R.id.emailEditText);
		passwordEditText = (EditText) findViewById(R.id.passwordEditText);
		phoneEditText = (EditText) findViewById(R.id.phoneEditText);

		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		homeRelativeLayout.setBackgroundResource(R.drawable.tablecellselected);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout) findViewById(R.id.logOutRelativeLayout);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);
		FrameLayout mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLyout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		LoginActivity.applyFonts(mainFrameLayout, font);
		messageNotificationTextView = (TextView) findViewById(R.id.messageNotificationTextView);
		calendarNotificationTextView = (TextView) findViewById(R.id.calendarNotificationTextView);
		messageNotificationTextView.setTypeface(font_bold);
		calendarNotificationTextView.setTypeface(font_bold);
		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
		new myTask_getUserDetails_call().execute();
	}

	void checkPassword(String oldpassword, String newpassword) {
		if (oldpassword.equals(passwordEditText.getText().toString())
				&& !newpassword.equals("")) {
			new myTask_changeUserPassword_call().execute();
		} else {
			final AlertDialog alertDialog = new AlertDialog.Builder(
					SettingsActivity.this).create();
			alertDialog.setTitle("");
			alertDialog.setMessage("Your old password doesn't match");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

					alertDialog.dismiss();
				}
			});
			alertDialog.show();

		}
	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(SettingsActivity.this,
					FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(SettingsActivity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(SettingsActivity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(SettingsActivity.this,
					MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(SettingsActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(SettingsActivity.this,
					CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = SettingsActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();
			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(SettingsActivity.this,
					LoginActivity.class);
			startActivity(intent);
		}
	}

	// DownloadJSON AsyncTask for saveUserDetails upload
	class myTask_saveUserDetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			uploadData();
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			final AlertDialog alertDialog = new AlertDialog.Builder(
					SettingsActivity.this).create();
			alertDialog.setTitle("");
			alertDialog.setMessage("Your Details are saved successfully");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

					alertDialog.dismiss();
				}
			});
			alertDialog.show();

			if (mProgressDialog != null)
				mProgressDialog.dismiss();

		}

	}

	// DownloadJSON AsyncTask for changeUserPassword upload
	class myTask_changeUserPassword_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {

			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient.execute(new HttpGet(
						"http://www.mobiwebcode.com/communication/updatepassword.php?userid="
								+ LoginActivity.userid + "&password="
								+ newpassword));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			final AlertDialog alertDialog = new AlertDialog.Builder(
					SettingsActivity.this).create();
			alertDialog.setTitle("");
			alertDialog.setMessage("Your Details are saved successfully");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

					alertDialog.dismiss();
				}
			});

			alertDialog.show();

			if (mProgressDialog != null)
				mProgressDialog.dismiss();

		}

	}

	// DownloadJSON AsyncTask for getUserDetails
	class myTask_getUserDetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {

			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				URL url = new URL(
						"http://mobiwebcode.com/communication/getuserdetail_Android.php?userid="
								+ LoginActivity.userid);

				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/getuserdetail_Android.php?userid="
								+ LoginActivity.userid));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {

			try {
				JSONObject jso = new JSONObject(responseString);
				final JSONObject jso_data = jso.getJSONObject("userdetails")
						.getJSONObject("user");

				if (!jso_data.isNull("username")
						&& !jso_data.getString("username").equals("[]"))
					usernameEditText.setText(jso_data.getString("username"));
				if (!jso_data.isNull("title")
						&& !jso_data.getString("title").equals("[]"))
					titleEditText.setText(jso_data.getString("title"));
				if (!jso_data.isNull("gender")) {
					if (jso_data.getString("gender").equalsIgnoreCase("male"))
						maleRadioButton.setChecked(true);
					else
						femaleRadioButton.setChecked(true);
				}

				if (!jso_data.isNull("company")
						&& !jso_data.getString("company").equals("[]"))
					companyEditText.setText(jso_data.getString("company"));
				if (!jso_data.isNull("about")
						&& !jso_data.getString("about").equals("[]"))
					aboutEditText.setText(jso_data.getString("about"));
				if (!jso_data.isNull("email")
						&& !jso_data.getString("email").equals("[]"))
					emailEditText.setText(jso_data.getString("email"));
				if (!jso_data.isNull("phone")
						&& !jso_data.getString("phone").equals("[]"))
					phoneEditText.setText(jso_data.getString("phone"));
				if (!jso_data.isNull("password")
						&& !jso_data.getString("password").equals("[]"))
					passwordEditText.setText(jso_data.getString("password"));
				if (!jso_data.isNull("picture")) {
					final Thread mThread = new Thread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								image = BitmapFactory.decodeStream(new URL(
										jso_data.getString("picture").replace(
												"\\/", "/")).openConnection()
										.getInputStream());
							} catch (Exception e) {
								// TODO: handle exception
								e.printStackTrace();
							}
						}
					});
					mThread.start();
					Thread joinerThread = new Thread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								mThread.join();
							} catch (Exception e) {
								// TODO: handle exception
								e.printStackTrace();
							} finally {
								SettingsActivity.this
										.runOnUiThread(new Runnable() {

											@Override
											public void run() {
												// TODO Auto-generated method
												// stub
												image = Bitmap
														.createScaledBitmap(
																image,
																userImageButton
																		.getWidth(),
																userImageButton
																		.getHeight(),
																true);
												userImageButton
														.setImageBitmap(image);
											}
										});

							}
						}
					});
					joinerThread.start();
				}

				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	// Create GetPicture method
	public void showPictureDialogue() {
		AlertDialog.Builder builder = new AlertDialog.Builder(
				SettingsActivity.this);

		new AlertDialog.Builder(SettingsActivity.this)
				.setMessage("Choose option")
				.setCancelable(false)
				.setPositiveButton("Gallery",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent();
								intent.setType("image/*");
								intent.setAction(Intent.ACTION_GET_CONTENT);
								startActivityForResult(Intent.createChooser(
										intent, "Select Picture"),
										PICK_FROM_FILE);
								dialog.dismiss();

							}
						})
				.setNegativeButton("Camera",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								try {

									Intent intent = new Intent(
											MediaStore.ACTION_IMAGE_CAPTURE);
									File file = new File(
											Environment
													.getExternalStorageDirectory(),
											"aaa_"
													+ String.valueOf(System
															.currentTimeMillis())
													+ ".jpg");
									mImageCaptureUri = Uri.fromFile(file);

									intent.putExtra(
											android.provider.MediaStore.EXTRA_OUTPUT,
											mImageCaptureUri);
									intent.putExtra("return-data", true);

									startActivityForResult(intent,
											PICK_FROM_CAMERA);
									dialog.dismiss();
								} catch (Exception e) {
									// TODO: handle exception
								}

							}
						})
				.setNeutralButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								// Perform Your Task Here--When No is pressed
								dialog.dismiss();
							}
						}).show();

	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;
		else {

			if (requestCode == PICK_FROM_CAMERA && resultCode == RESULT_OK) {
				mPath = mImageCaptureUri.getPath();
				photo = BitmapFactory.decodeFile(mPath);
			} else {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };
				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);
				cursor.close();

				photo = BitmapFactory.decodeFile(picturePath);

			}
			photo = Bitmap.createScaledBitmap(photo, 60, 60, true);
			image = Bitmap.createScaledBitmap(photo,
					userImageButton.getWidth(), userImageButton.getHeight(),
					true);
			userImageButton.setImageBitmap(image);
		}
	}

	// Create GetText Method
	public void uploadData() {
		String gender = "";
		if (maleRadioButton.isChecked())
			gender = "Male";
		else
			gender = "Female";
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		if (photo != null) {
			image = photo;
		}
		Bitmap bi = image;
		bi.compress(Bitmap.CompressFormat.PNG, 100, baos);
		byte[] data = baos.toByteArray();
		nameValuePair.add(new BasicNameValuePair("image", Base64
				.encodeToString(data, 0)));

		SharedPreferences myPrefs = SettingsActivity.this.getSharedPreferences(
				"myPrefs", MODE_WORLD_READABLE);
		nameValuePair.add(new BasicNameValuePair("username", usernameEditText
				.getText().toString()));
		nameValuePair.add(new BasicNameValuePair("title", titleEditText
				.getText().toString()));
		nameValuePair.add(new BasicNameValuePair("gender", gender));

		nameValuePair.add(new BasicNameValuePair("company", companyEditText
				.getText().toString()));
		nameValuePair.add(new BasicNameValuePair("email", emailEditText
				.getText().toString()));
		nameValuePair.add(new BasicNameValuePair("phone", phoneEditText
				.getText().toString()));
		nameValuePair
				.add(new BasicNameValuePair("userid", LoginActivity.userid));
		nameValuePair.add(new BasicNameValuePair("about", aboutEditText
				.getText().toString()));
		try {

			// Defined URL where to send data
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://www.mobiwebcode.com/communication/mobile_updateuser_android.php");
			httppost.setHeader("Content-Type",
					"application/x-www-form-urlencoded;");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair, "UTF-8"));
			HttpResponse response = httpclient.execute(httppost);
			String responseText = EntityUtils.toString(response.getEntity());
			System.out.println(responseText);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	@Override
	public void onBackPressed() {

	}

	// validating email id
	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	// validating password with retype password
	private boolean isValidPassword(String pass) {
		if (pass != null && pass.length() > 6) {
			return true;
		}
		return false;
	}
}