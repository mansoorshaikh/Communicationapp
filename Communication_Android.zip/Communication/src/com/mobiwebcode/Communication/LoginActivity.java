package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.service.textservice.SpellCheckerService.Session;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

public class LoginActivity extends Activity {
	private SQLiteDatabase CommunicationDatabase;
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	private ProgressDialog mProgressDialog;
	String isMerchant = "";
	String responseString = null;
	String LoginDetails = "logindetails";
	private static String DB_PATH = "/data/data/com.mobiwebcode.Communication/databases/";
	private static final String DB_NAME = "communication.db";
	private String path = DB_PATH + DB_NAME;
	/** Called when the activity is first created. */
	RelativeLayout mainRelativeLayout;
	private static final int PICK_FROM_CAMERA = 1;
	private static final int PICK_FROM_FILE = 2;
	private Uri mImageCaptureUri;
	ImageButton userImageButton;
	Bitmap image;
	private String mPath = "";
	Bitmap photo = null;
	EditText Username, Password;
	public static String userid = "";
	ToggleButton tB;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();

			return mProgressDialog;

		default:
			return null;
		}
	}

	private void copyDatabase() {
		try {
			File f = new File(path);
			File f2 = new File(DB_PATH);
			if (!f.exists()) {
				InputStream in = getAssets().open("Communication.sqlite");
				if (!f2.exists())
					f2.mkdir();
				OutputStream out = new FileOutputStream(path);

				byte[] buffer = new byte[1024];
				int length;
				while ((length = in.read(buffer)) > 0) {
					out.write(buffer, 0, length);
				}
				in.close();
				out.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		userImageButton = (ImageButton) findViewById(R.id.userImageButton);
		userImageButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showPictureDialogue();
			}
		});
		Username = (EditText) findViewById(R.id.usernameEditText);
		Password = (EditText) findViewById(R.id.passwordEditText);
		mainRelativeLayout = (RelativeLayout) findViewById(R.id.mainRelativeLayout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		applyFonts(mainRelativeLayout, font);

		  tB = (ToggleButton) findViewById(R.id.togglebutton);
		
		SharedPreferences myPrefs = LoginActivity.this.getSharedPreferences(
				"myPrefs", MODE_WORLD_READABLE);
		SharedPreferences.Editor prefsEditor = myPrefs.edit();

		if (myPrefs.getString("login", "") != null
				&& !myPrefs.getString("login", "").equals("")) {
			userid = myPrefs.getString("login", "nothing").trim();
			Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
			startActivity(intent);
		}

	}

	// Create GetPicture method
	public void showPictureDialogue() {
		AlertDialog.Builder builder = new AlertDialog.Builder(
				LoginActivity.this);

		new AlertDialog.Builder(LoginActivity.this)
				.setMessage("Choose option")
				.setCancelable(false)
				.setPositiveButton("Gallery",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent();
								intent.setType("image/*");
								intent.setAction(Intent.ACTION_GET_CONTENT);
								startActivityForResult(Intent.createChooser(
										intent, "Select Picture"),
										PICK_FROM_FILE);
								dialog.dismiss();

							}
						})
				.setNegativeButton("Camera",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								try {

									Intent intent = new Intent(
											MediaStore.ACTION_IMAGE_CAPTURE);
									File file = new File(
											Environment
													.getExternalStorageDirectory(),
											"aaa_"
													+ String.valueOf(System
															.currentTimeMillis())
													+ ".jpg");
									mImageCaptureUri = Uri.fromFile(file);

									intent.putExtra(
											android.provider.MediaStore.EXTRA_OUTPUT,
											mImageCaptureUri);
									intent.putExtra("return-data", true);

									startActivityForResult(intent,
											PICK_FROM_CAMERA);
									dialog.dismiss();
								} catch (Exception e) {
									// TODO: handle exception
								}

							}
						})
				.setNeutralButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								// Perform Your Task Here--When No is pressed
								dialog.dismiss();
							}
						}).show();

	}

	// DownloadJSON AsyncTask for saveImages upload
	class myTask_saveImages_call extends AsyncTask<String, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(String... params) {
			uploadData(photo);
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			if(tB.isChecked()){
			SharedPreferences myPrefs = LoginActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", responseString.trim());
			prefsEditor.commit();
			}
			userid = responseString.trim();
			if (mProgressDialog != null)
				mProgressDialog.dismiss();
			
			Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
			startActivity(intent);
		}

	}

	// Create GetText Method
	public void uploadData(Bitmap photo) {

		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Bitmap bi = photo;
		bi.compress(Bitmap.CompressFormat.PNG, 100, baos);
		byte[] data = baos.toByteArray();
		nameValuePair.add(new BasicNameValuePair("image", Base64
				.encodeToString(data, 0)));

		nameValuePair.add(new BasicNameValuePair("email", Username.getText()
				.toString()));
		nameValuePair.add(new BasicNameValuePair("password", Password.getText()
				.toString()));
		try {

			// Defined URL where to send data
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://mobiwebcode.com/communication/login_android.php");
			httppost.setHeader("Content-Type",
					"application/x-www-form-urlencoded;");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair, "UTF-8"));
			HttpResponse response = httpclient.execute(httppost);
			responseString = EntityUtils.toString(response.getEntity());
			System.out.println(responseString + "response is display");

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;
		else {

			if (requestCode == PICK_FROM_CAMERA && resultCode == RESULT_OK) {
				mPath = mImageCaptureUri.getPath();
				photo = BitmapFactory.decodeFile(mPath);
			} else {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };
				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);
				cursor.close();

				photo = BitmapFactory.decodeFile(picturePath);

			}
			photo = Bitmap.createScaledBitmap(photo, 60, 60, true);
			image = Bitmap.createScaledBitmap(photo,
					userImageButton.getWidth(), userImageButton.getHeight(),
					true);
			userImageButton.setImageBitmap(image);
		}
	}

	public void loginFunction(View view) {

		final String email = Username.getText().toString();
		final String password = Password.getText().toString();
		if (!isValidEmail(email)) {
			Username.setError("Invalid Email");
			Username.requestFocus();
		} else if (!isValidPassword(password)) {
			Password.setError("Invalid Password");
			Password.requestFocus();
		}
		if (isValidEmail(email) && isValidPassword(password)) {
			if (photo == null)
				new myTask_registerUser_call().execute("");
			else
				new myTask_saveImages_call().execute();
		}

	}

	// register User call

	class myTask_registerUser_call extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		protected String doInBackground(String... aurl) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/login.php?email="
								+ Username.getText().toString() + "&password="
								+ Password.getText().toString()));
				StatusLine statusLine = response.getStatusLine();
				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return "";
		}

		protected void onPostExecute(String str_resp) {

			if (responseString.equals("1")) {
				final AlertDialog alertDialog = new AlertDialog.Builder(
						LoginActivity.this).create();
				alertDialog.setTitle("");
				alertDialog
						.setMessage("Your access has been rehoked, please contact admin !!!");
				alertDialog.setButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								alertDialog.dismiss();
							}
						});
				alertDialog.show();
			} else if (responseString.equals("0")) {
				final AlertDialog alertDialog = new AlertDialog.Builder(
						LoginActivity.this).create();
				alertDialog.setTitle("");
				alertDialog
						.setMessage("Please wait for granted permission to admin ");
				alertDialog.setButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {

								alertDialog.dismiss();
							}
						});
				alertDialog.show();
			} else {
				if(tB.isChecked()){
				SharedPreferences myPrefs = LoginActivity.this
						.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
				SharedPreferences.Editor prefsEditor = myPrefs.edit();
				prefsEditor.putString("login", responseString.trim());
				prefsEditor.commit();
				}
				userid = responseString.trim();
				

				Intent intent = new Intent(LoginActivity.this,
						HomeActivity.class);
				startActivity(intent);
			}

			if (mProgressDialog != null)
				mProgressDialog.dismiss();

		}
	}

	public static void applyFonts(final View v, Typeface fontToSet) {
		try {
			if (v instanceof ViewGroup) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0; i < vg.getChildCount(); i++) {
					View child = vg.getChildAt(i);
					applyFonts(child, fontToSet);
				}
			} else if (v instanceof TextView) {
				((TextView) v).setTypeface(fontToSet);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// ignore
		}
	}

	public void addLogindetails() {
		try {

			ContentValues values = new ContentValues();
			values.put("username", Username.getText().toString());
			values.put("password", Password.getText().toString());
			long userid = Constants.CommunicationDatabase.insert(LoginDetails,
					null, values);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public int readLogindetails() {
		int Login = 0;
		try {

			Cursor cursor = null;

			cursor = Constants.CommunicationDatabase.rawQuery("SELECT * FROM "
					+ LoginDetails, null);
			if (cursor.getCount() > 0) {

			}
			cursor.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Login;
	}

	// validating email id
	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	// validating password with retype password
	private boolean isValidPassword(String pass) {
		if (pass != null && pass.length() > 6) {
			return true;
		}
		return false;
	}
}
