package com.mobiwebcode.Communication;

public class FeedTypeVO {
	public String feedid = "",feedtype = "";
}
