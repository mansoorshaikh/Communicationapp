package com.mobiwebcode.Communication;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class Activity_Activity extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout;

	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	String responseString = "";
	ArrayList<ActivityVO> activitylist = new ArrayList<ActivityVO>();
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	ListView listview;
	
	TextView userName;
	NormalSmartImageView userImage;
	
	FrameLayout mainFrameLyout;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	private ProgressDialog mProgressDialog;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	public static void applyFonts(final View v, Typeface fontToSet) {
		try {
			if (v instanceof ViewGroup) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0; i < vg.getChildCount(); i++) {
					View child = vg.getChildAt(i);
					applyFonts(child, fontToSet);
				}
			} else if (v instanceof TextView) {
				((TextView) v).setTypeface(fontToSet);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// ignore
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activitylayout);
		
		userImage = (NormalSmartImageView)findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView)findViewById(R.id.activityUsername);
		userName.setText(HomeActivity.username);
		
		mainFrameLyout = (FrameLayout) findViewById(R.id.mainFrameLyout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		applyFonts(mainFrameLyout, font);
		Constants.MENU_ITEM_SELECTED = "ACTIVITY";
		listview = (ListView) findViewById(R.id.list);
		listview.setCacheColorHint(Color.TRANSPARENT);
		
			
			new myTask_activityDetails_call().execute();
	

		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		activityRelativeLayout
				.setBackgroundResource(R.drawable.tablecellselected);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);

//		final ListArrayAdapter adapter = new ListArrayAdapter(this,
//				menuArrayList);
//		listview.setAdapter(adapter);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});
	}
	
	// DownloadJSON AsyncTask for activityDetails
	class myTask_activityDetails_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient
						.execute(new HttpGet(
								"http://www.mobiwebcode.com/communication/ActivityDetail.php"));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				JSONObject jso = new JSONObject(responseString);
				JSONArray activityArray = jso.getJSONObject("activitydetail")
						.getJSONArray("activity");
				for (int i = 0; i < activityArray.length(); i++) {

					JSONObject activityObject = (JSONObject) activityArray
							.get(i);
					ActivityVO aVo = new ActivityVO();
					if (!activityObject.isNull("userimage"))
						aVo.userimage = activityObject.getString("userimage");
					if (!activityObject.isNull("username"))
						aVo.username = activityObject.getString("username");
					if (!activityObject.isNull("message"))
						aVo.activitydetails = activityObject
								.getString("message");
					if (!activityObject.isNull("date"))
						aVo.date = activityObject.getString("date");
					activitylist.add(aVo);

				}
				final ListArrayAdapterActivity adapter = new ListArrayAdapterActivity(
						Activity_Activity.this, activitylist);
				listview.setAdapter(adapter);

				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(Activity_Activity.this,
					HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(Activity_Activity.this,
					FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			Intent intent = new Intent(Activity_Activity.this,
					CameraDetailsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(Activity_Activity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(Activity_Activity.this,
					MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(Activity_Activity.this,
					CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(Activity_Activity.this,
					SettingsActivity.class);
			startActivity(intent);
		}else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = Activity_Activity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();

			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(Activity_Activity.this,
					LoginActivity.class);
			startActivity(intent);
		}
		
	}
	@Override
	public void onBackPressed() {
		
	}
}
