package com.mobiwebcode.Communication;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import app.tabsample.SmartImageView.NormalSmartImageView;

public class CameraDetailsActivity extends Activity {
	RelativeLayout homeRelativeLayout, feedRelativeLayout,
			cameraRelativeLayout, calendarRelativeLayout, mediaRelativeLayout,
			activityRelativeLayout, createRelativeLayout, logOutRelativeLayout;
	LinearLayout cameraPhotosRelativeLayout;
	LinearLayout scrollviewLinearLayout;
	private LinearLayout slidingPanel;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private ListView listView;
	private RelativeLayout headerPanel;
	private RelativeLayout menuPanel;
	private int panelWidth;
	private ImageView menuViewButton;
	int index = 0;
	public static String userid = "";
	private ProgressDialog mProgressDialog;
	Bitmap photo = null;
	String responseString = "";
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	private static final int PICK_FROM_CAMERA = 1;
	private static final int PICK_FROM_FILE = 2;
	private Uri mImageCaptureUri;
	private String mPath = "";
	private Bitmap bmp;
	FrameLayout mainFrameLayout;
	NormalSmartImageView cameraPic,userImage;
	TextView userName;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	ArrayList<MenuVO> menuArrayList = new ArrayList<MenuVO>();
	ArrayList<ImageVO> imageList = new ArrayList<ImageVO>();

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();

			return mProgressDialog;

		default:
			return null;
		}
	}

	public void displayGallery(View view) {
		Intent intent = new Intent();
		intent.setType("image/*");
		intent.setAction(Intent.ACTION_GET_CONTENT);
		startActivityForResult(Intent.createChooser(intent, "Select Picture"),
				PICK_FROM_FILE);
	}

	public void displayCamera(View view) {
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		File file = new File(Environment.getExternalStorageDirectory(), "aaa_"
				+ String.valueOf(System.currentTimeMillis()) + ".jpg");
		mImageCaptureUri = Uri.fromFile(file);

		try {
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.putExtra("return-data", true);

			startActivityForResult(intent, PICK_FROM_CAMERA);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cameradetails);
		Constants.MENU_ITEM_SELECTED = "CAMERA";
		
		userImage = (NormalSmartImageView)findViewById(R.id.icon);
		userImage.setImageUrl(HomeActivity.userimage);
		userName = (TextView)findViewById(R.id.cameraUsername);
		userName.setText(HomeActivity.username);

		scrollviewLinearLayout = (LinearLayout) findViewById(R.id.scrollviewLinearLayout);
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated

		scrollviewLinearLayout
				.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(
						width, height - 155));
		cameraPhotosRelativeLayout = (LinearLayout) findViewById(R.id.cameraRelativeLayout);
		homeRelativeLayout = (RelativeLayout) findViewById(R.id.homeTitleRelativeLayout);
		feedRelativeLayout = (RelativeLayout) findViewById(R.id.feedTitleRelativeLayout);
		cameraRelativeLayout = (RelativeLayout) findViewById(R.id.cameraTitleRelativeLayout);
		cameraRelativeLayout
				.setBackgroundResource(R.drawable.tablecellselected);
		calendarRelativeLayout = (RelativeLayout) findViewById(R.id.calendarTitleRelativeLayout);
		mediaRelativeLayout = (RelativeLayout) findViewById(R.id.mediaTitleRelativeLayout);
		activityRelativeLayout = (RelativeLayout) findViewById(R.id.activityTitleRelativeLayout);
		createRelativeLayout = (RelativeLayout) findViewById(R.id.createTitleRelativeLayout);
		logOutRelativeLayout = (RelativeLayout) findViewById(R.id.logOutRelativeLayout);
		mainFrameLayout = (FrameLayout) findViewById(R.id.mainFrameLayout);
		Typeface font = Typeface.createFromAsset(this.getAssets(),
				"GothamNarrow-Light.otf");
		LoginActivity.applyFonts(mainFrameLayout, font);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);

		headerPanel = (RelativeLayout) findViewById(R.id.header);
		headerPanelParameters = (LinearLayout.LayoutParams) headerPanel
				.getLayoutParams();
		headerPanelParameters.width = metrics.widthPixels;
		headerPanel.setLayoutParams(headerPanelParameters);

		menuPanel = (RelativeLayout) findViewById(R.id.menuPanel);
		menuPanelParameters = (FrameLayout.LayoutParams) menuPanel
				.getLayoutParams();
		menuPanelParameters.width = panelWidth;
		menuPanel.setLayoutParams(menuPanelParameters);

		slidingPanel = (LinearLayout) findViewById(R.id.slidingPanel);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		// Slide the Panel
		menuViewButton = (ImageView) findViewById(R.id.menuViewButton);
		menuViewButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}

			}
		});
		new myTask_getimages_call().execute();
		// scrollviewLinearLayout.addView(cameraPictureButton);

	}

	void fillCameraPicture() {
		cameraPhotosRelativeLayout.removeAllViews();
		Display display = getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated

		int x = 0, y = 0;
		int k = 0;
		LinearLayout picsLayout = new LinearLayout(CameraDetailsActivity.this);
		picsLayout.setOrientation(LinearLayout.HORIZONTAL);
		LayoutParams picsLayoutparams = new LayoutParams(
				LayoutParams.FILL_PARENT, width / 3);
		picsLayout.setLayoutParams(picsLayoutparams);
		for (int count = 0; count < imageList.size(); count++) {
			final ImageVO iVo = imageList.get(count);
			NormalSmartImageView cameraPic = new NormalSmartImageView(
					CameraDetailsActivity.this);
			cameraPic.setId(count);
			// Image setOnclickListener
			cameraPic.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					final Dialog dialog = new Dialog(CameraDetailsActivity.this);
					dialog.setContentView(R.layout.actionsheet);
					ImageButton closeButton = (ImageButton) dialog
							.findViewById(R.id.closeButton);
					ImageButton sendButton = (ImageButton) dialog
							.findViewById(R.id.sendButton);
					ImageButton savebutton = (ImageButton) dialog
							.findViewById(R.id.savebutton);
					ImageButton deleteButton = (ImageButton) dialog
							.findViewById(R.id.deleteButton);
					index = v.getId();

					dialog.show();
					closeButton.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							dialog.dismiss();
						}
					});
					sendButton.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							saveFiletoSDcard(iVo.imagepath);
							File sdCardDirectory = Environment
									.getExternalStorageDirectory();

							String s[] = iVo.imagepath.split("/");
							String result = s[s.length - 1];

							File image = new File(sdCardDirectory, result);
							Intent i = new Intent(Intent.ACTION_SEND);

							i.putExtra(Intent.EXTRA_EMAIL,
									new String[] { "neffchip@gmail.com" });
							i.putExtra(Intent.EXTRA_SUBJECT, "Send Message");
							i.putExtra(Intent.EXTRA_TEXT, "");
							i.setType("image/jpeg");

							Uri myUri = Uri.fromFile(image);
							i.putExtra(Intent.EXTRA_STREAM, myUri);
							try {
								CameraDetailsActivity.this.startActivity(Intent
										.createChooser(i, "Send mail..."));
							} catch (android.content.ActivityNotFoundException ex) {
								Toast.makeText(
										CameraDetailsActivity.this,
										"There are no email clients installed.",
										Toast.LENGTH_SHORT).show();
							}

						}
					});
					savebutton.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							saveFiletoSDcard(iVo.imagepath);
						}
					});
					deleteButton.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							new myTask_deleteImages_call().execute();
						}
					});

				}
			});
			cameraPic.setImageUrl(iVo.imagepath.replace("\\/", "/"));
			LayoutParams params = new LayoutParams(width / 3, width / 3);

			if (k == 0) {
				k = 1;
				params = new LayoutParams(width / 3, width / 3);
				cameraPic.setLayoutParams(params);
				picsLayout.addView(cameraPic);

			} else if (k == 1) {
				params = new LayoutParams(width / 3, width / 3);
				k = 2;
				cameraPic.setLayoutParams(params);
				picsLayout.addView(cameraPic);
			} else if (k == 2) {
				if (count == 11) {
					RelativeLayout cameraPicRelativeLayout = new RelativeLayout(
							CameraDetailsActivity.this);
					cameraPicRelativeLayout.setGravity(Gravity.CENTER);
					cameraPicRelativeLayout.setLayoutParams(new LayoutParams(
							width / 3, width / 3));
					cameraPic.setLayoutParams(params);
					cameraPicRelativeLayout.addView(cameraPic);

					picsLayout.addView(cameraPicRelativeLayout);
				} else {
					params = new LayoutParams(width / 3, width / 3);
					cameraPic.setLayoutParams(params);
					picsLayout.addView(cameraPic);
				}
				k = 0;
				cameraPhotosRelativeLayout.addView(picsLayout);
				picsLayout = new LinearLayout(CameraDetailsActivity.this);
				picsLayout.setLayoutParams(picsLayoutparams);
			}

			if (count == imageList.size() - 1) {
				cameraPhotosRelativeLayout.addView(picsLayout);
				picsLayout = new LinearLayout(CameraDetailsActivity.this);
				picsLayout.setLayoutParams(picsLayoutparams);
			}
		}

		Button cameraPictureButton = new Button(CameraDetailsActivity.this);
		cameraPictureButton
				.setBackgroundResource(R.drawable.camera_camerascreen);
		LayoutParams cameraLayoutParams = new LayoutParams(40, 40);
		cameraLayoutParams.setMargins(width - 150, height - 250, 0, 0);
		cameraPictureButton.setLayoutParams(cameraLayoutParams);
		cameraPictureButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// displayCamera();
			}
		});

	}

	void saveFiletoSDcard(final String imagepath) {
		final Thread worker = new Thread(new Runnable() {
			public void run() {/* work thread stuff here */

				File sdCardDirectory = Environment
						.getExternalStorageDirectory();

				String s[] = imagepath.split("/");
				String result = s[s.length - 1];

				File image = new File(sdCardDirectory, result);
				if (!image.exists()) {

					boolean success = false;

					// Encode the file as a PNG image.
					try {

						InputStream input = new BufferedInputStream(new URL(
								imagepath).openStream());
						OutputStream output = new FileOutputStream(image);
						byte data[] = new byte[1024];
						while (input.read(data) != -1) {
							output.write(data);
						}
						output.flush();
						output.close();
						input.close();
						success = true;
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		});
		worker.start();

	}

	public void showActionSheet(View v) {
		final Dialog dialog = new Dialog(CameraDetailsActivity.this);
		dialog.setContentView(R.layout.actionsheet);
		ImageButton closeButton = (ImageButton) dialog
				.findViewById(R.id.closeButton);
		dialog.show();
		closeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
	}

	public void onMenuOptionClicked(View view) {
		if (view.getId() == R.id.homeTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "HOME";
			Intent intent = new Intent(CameraDetailsActivity.this,
					HomeActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.feedTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "FEED";
			Intent intent = new Intent(CameraDetailsActivity.this,
					FeedsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.cameraTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CAMERA";
			new CollapseAnimation(slidingPanel, panelWidth,
					TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
					TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f, 0, 0.0f);
		} else if (view.getId() == R.id.calendarTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CALENDAR";
			Intent intent = new Intent(CameraDetailsActivity.this,
					CalendarActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.mediaTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "MEDIA";
			Intent intent = new Intent(CameraDetailsActivity.this,
					MediaActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.activityTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "ACTIVITY";
			Intent intent = new Intent(CameraDetailsActivity.this,
					Activity_Activity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.createTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "CREATE";
			Intent intent = new Intent(CameraDetailsActivity.this,
					CreateActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.settingsTitleRelativeLayout) {
			Constants.MENU_ITEM_SELECTED = "SETTINGS";
			Intent intent = new Intent(CameraDetailsActivity.this,
					SettingsActivity.class);
			startActivity(intent);
		} else if (view.getId() == R.id.logOutRelativeLayout) {
			SharedPreferences myPrefs = CameraDetailsActivity.this
					.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
			SharedPreferences.Editor prefsEditor = myPrefs.edit();
			prefsEditor.putString("login", "");
			prefsEditor.commit();
			Constants.MENU_ITEM_SELECTED = "LogOut";
			Intent intent = new Intent(CameraDetailsActivity.this,
					LoginActivity.class);
			startActivity(intent);
		}
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;
		else {

			if (requestCode == PICK_FROM_CAMERA && resultCode == RESULT_OK) {
				mPath = mImageCaptureUri.getPath();
				photo = BitmapFactory.decodeFile(mPath);
			} else {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };
				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);
				cursor.close();

				photo = BitmapFactory.decodeFile(picturePath);

			}
			photo = Bitmap.createScaledBitmap(photo, 60, 60, true);
			new myTask_saveImages_call().execute();
		}
	}

	public String getRealPathFromURI(Uri contentUri) {
		String[] proj = { MediaStore.Images.Media.DATA };
		Cursor cursor = managedQuery(contentUri, proj, null, null, null);

		if (cursor == null)
			return null;

		int column_index = cursor
				.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

		cursor.moveToFirst();

		return cursor.getString(column_index);
	}

	// DownloadJSON AsyncTask for saveImages upload
	class myTask_saveImages_call extends AsyncTask<String, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(String... params) {
			uploadData(photo);
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			final AlertDialog alertDialog = new AlertDialog.Builder(
					CameraDetailsActivity.this).create();
			alertDialog.setTitle("");
			alertDialog.setMessage("Your image saved successfully");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

					alertDialog.dismiss();
				}
			});
			alertDialog.show();
			if (mProgressDialog != null)
				mProgressDialog.dismiss();
			new myTask_getimages_call().execute();

		}

	}

	// DownloadJSON AsyncTask for deleteImages upload
	class myTask_deleteImages_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				ImageVO iVo = imageList.get(index);
				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/deletepicture.php?pictureid="
								+ iVo.imageid));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			final AlertDialog alertDialog = new AlertDialog.Builder(
					CameraDetailsActivity.this).create();
			alertDialog.setTitle("");
			alertDialog.setMessage("Your image delete successfully");
			alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

					alertDialog.dismiss();
				}
			});
			// alertDialog.show();
			if (mProgressDialog != null)
				mProgressDialog.dismiss();
			new myTask_getimages_call().execute();

		}

	}

	// Create GetText Method
	public void uploadData(Bitmap photo) {

		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Bitmap bi = photo;
		bi.compress(Bitmap.CompressFormat.PNG, 100, baos);
		byte[] data = baos.toByteArray();
		nameValuePair.add(new BasicNameValuePair("image", Base64
				.encodeToString(data, 0)));

		SharedPreferences myPrefs = CameraDetailsActivity.this
				.getSharedPreferences("myPrefs", MODE_WORLD_READABLE);
		nameValuePair
				.add(new BasicNameValuePair("userid", LoginActivity.userid));

		try {

			// Defined URL where to send data
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(
					"http://mobiwebcode.com/communication/mobile_uploadpicture_android.php");
			httppost.setHeader("Content-Type",
					"application/x-www-form-urlencoded;");
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair, "UTF-8"));
			HttpResponse response = httpclient.execute(httppost);
			String responseText = EntityUtils.toString(response.getEntity());
			System.out.println(responseText + "response is display");

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	// DownloadJSON AsyncTask for getimages

	class myTask_getimages_call extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		@Override
		protected Void doInBackground(Void... params) {
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {

				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/communication/imagelist.php?userid="
								+ LoginActivity.userid));
				StatusLine statusLine = response.getStatusLine();

				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return null;

		}

		@Override
		protected void onPostExecute(Void args) {
			try {
				if (!responseString.equals("no")) {
					imageList.clear();
					JSONObject jso = new JSONObject(responseString);
					JSONArray imageArray = jso.getJSONObject("imagedetails")
							.getJSONArray("image");
					for (int i = 0; i < imageArray.length(); i++) {

						JSONObject activityObject = (JSONObject) imageArray
								.get(i);
						ImageVO iVo = new ImageVO();
						if (!activityObject.isNull("imageid"))
							iVo.imageid = activityObject.getString("imageid");
						if (!activityObject.isNull("imagepath"))
							iVo.imagepath = activityObject
									.getString("imagepath");

						imageList.add(iVo);

					}
				}
				fillCameraPicture();
				if (mProgressDialog != null)
					mProgressDialog.dismiss();

			} catch (Exception e) {
				e.printStackTrace();
				if (mProgressDialog != null)
					mProgressDialog.dismiss();
			}
		}
	}

	@Override
	public void onBackPressed() {

	}
}
