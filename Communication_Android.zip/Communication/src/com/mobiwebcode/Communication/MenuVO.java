package com.mobiwebcode.Communication;

public class MenuVO {
	public int icon;
	public String title;
	public String secondTitle;
	public String time;

	public MenuVO() {
		super();
	}

	public MenuVO(int icon, String title, String secondTitle, String time) {
		super();
		this.icon = icon;
		this.title = title;
		this.secondTitle = secondTitle;
		this.time = time;
	}
}
