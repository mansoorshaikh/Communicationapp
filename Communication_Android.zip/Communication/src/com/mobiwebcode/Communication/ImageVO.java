package com.mobiwebcode.Communication;

public class ImageVO {
	public String imageid = "",imagepath = "";

}
