package com.mobiwebcode.Communication;

public class ActivityVO {

	public String userimage = "", username = "", activitydetails = "",
			date = "", time = "", message = "";

}
