<?php
    
    require_once("pi_classes/Town.php");
    
    include_once('pi_classes/thumbnail_images.class.php');
    
    $objTown=new Town();
    $objTown2=new Town();
    
    $obj_img=new thumbnail_images();
    
    $uploaddir = 'photos/';
    
    $file = basename($_FILES['userfile']['name']);
    
    $model1=explode('_',$file);
    
    $objTown->getfeedlistwithfeedid($model1[0]);
    
    $objTown->getRow();
    
    if($objTown->getField('response')==""){
    
    $uploadfile = $uploaddir . $file;
    
    $oldFile=explode(".",$_FILES['userfile']['name']);
    
    $newFile=time().mt_rand();
    
    $target_path ="admin/userPhoto/"."".$newFile.".jpg";
    
    move_uploaded_file($_FILES['userfile']['tmp_name'],$target_path);
    
    $objTown2->feedserveywithimage_function($target_path,$model1);
    
    echo $target_path;
    }else{
        echo "0";
    }
    ?>