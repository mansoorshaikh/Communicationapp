<?php
    
    require_once("../pi_classes/Town.php");
    
    include_once('../pi_classes/thumbnail_images.class.php');
    
    $objTown=new Town();
    
    $obj_img=new thumbnail_images();
    
    $uploaddir = 'photos/';
    
    $file = basename($_FILES['userfile']['name']);
    
    $model1=explode('_',$file);
    
    $uploadfile = $uploaddir . $file;
    
    $oldFile=explode(".",$_FILES['userfile']['name']);
    
    $newFile=time().mt_rand();
    
    $target_path ="admin/userPhoto/"."".$newFile.".jpg";
    
    move_uploaded_file($_FILES['userfile']['tmp_name'],$target_path);
    
    $objTown->uploadpicture($model1[0],$target_path);
?>