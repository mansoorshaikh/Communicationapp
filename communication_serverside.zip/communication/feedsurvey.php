 <?PHP
     require_once('pi_classes/Town.php');
     $objTown=new Town();
     $objTown2=new Town();
     $objTown->getfeedlistwithfeedid($_REQUEST['feedid']);
     $objTown->getRow();
     
     if($objTown->getField('response')==""){

     $objTown2-> feedservey_function();
     echo $_REQUEST['response'];
     }else{
         echo "0";
     }
   ?>