-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 02, 2015 at 06:33 AM
-- Server version: 5.5.40-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mobiwebc_communicationDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE IF NOT EXISTS `admin_details` (
  `adminid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_details`
--

INSERT INTO `admin_details` (`adminid`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_events`
--

CREATE TABLE IF NOT EXISTS `calendar_events` (
  `calendareventid` int(11) NOT NULL AUTO_INCREMENT,
  `calendareventdate` varchar(256) NOT NULL,
  `calendareventtime` varchar(256) NOT NULL,
  `calendareventtext` text NOT NULL,
  PRIMARY KEY (`calendareventid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `calendar_events`
--

INSERT INTO `calendar_events` (`calendareventid`, `calendareventdate`, `calendareventtime`, `calendareventtext`) VALUES
(9, '03/19/2015', '2:12 AM', 'abcd'),
(12, '04/18/2015', '1:30 AM', 'videos');

-- --------------------------------------------------------

--
-- Table structure for table `feeds`
--

CREATE TABLE IF NOT EXISTS `feeds` (
  `feedid` int(11) NOT NULL AUTO_INCREMENT,
  `feedtype` varchar(256) NOT NULL,
  `feedpicture` varchar(256) NOT NULL,
  `feedtext` varchar(256) NOT NULL,
  `time` varchar(256) NOT NULL,
  `feeddescription` varchar(256) NOT NULL,
  `response` varchar(256) NOT NULL,
  `feedformat` varchar(256) NOT NULL,
  PRIMARY KEY (`feedid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `feeds`
--

INSERT INTO `feeds` (`feedid`, `feedtype`, `feedpicture`, `feedtext`, `time`, `feeddescription`, `response`, `feedformat`) VALUES
(1, 'xyz', 'userPhoto/definitions.png', 'feed 123', '03/03/2015', 'dfdfdfdfdfd', 'yes', 'Question'),
(2, 'abc1234', 'userPhoto/backgroundwassce.png', 'feed 1', '03/03/2015', 'tese desc', '', 'Normal'),
(3, 'xyz', 'userPhoto/categoryicon.png', 'feed 1', '03/07/2015', 'tese desc', '', 'Question'),
(5, 'xyz', 'userPhoto/greenbackbutton.png', 'image', '03/20/2015', 'image', '', 'Normal'),
(6, 'xyz', 'userPhoto/definitions.png', 'ssss', '03/10/2015', 'dddd', '', 'Normal'),
(7, 'abc', 'userPhoto/setup.png', 'picture', '03/17/2015', 'picture', '', 'Question'),
(8, 'abc1234', 'userPhoto/dragonbox-screen-grab1.jpg', 'img', '03/21/2015', 'img', 'No', 'Question'),
(11, 'abc', 'userPhoto/cameraicon.png', 'feed 1234', '04/27/2015', 'tese desc', '', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `feedtypes`
--

CREATE TABLE IF NOT EXISTS `feedtypes` (
  `feedtypeid` int(11) NOT NULL AUTO_INCREMENT,
  `feedtypename` varchar(256) NOT NULL,
  PRIMARY KEY (`feedtypeid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `feedtypes`
--

INSERT INTO `feedtypes` (`feedtypeid`, `feedtypename`) VALUES
(1, 'abc1234'),
(2, 'xyz'),
(6, 'test 1'),
(7, 'test 2'),
(8, 'test 3');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `mediaid` int(11) NOT NULL AUTO_INCREMENT,
  `medianame` varchar(256) NOT NULL,
  `mediadate` varchar(256) NOT NULL,
  `mediapath` varchar(256) NOT NULL,
  `mediapicture` varchar(256) NOT NULL,
  `youtubevideo` varchar(256) NOT NULL,
  PRIMARY KEY (`mediaid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`mediaid`, `medianame`, `mediadate`, `mediapath`, `mediapicture`, `youtubevideo`) VALUES
(11, 'sdsds', '03/13/2015', 'userMedia/small.mp4', 'userPhoto/chats.png', 'https://www.google.co.in/?gws_rd=ssl#q=youtube'),
(13, 'clipcanvas', '04/07/2015', 'userMedia/clipcanvas_14348_offline.mp4', 'userPhoto/1472989-note-book-with-sticker-and-pencil-over-there.jpg', 'https://www.google.co.in/?gws_rd=ssl#q=youtube'),
(14, 'updatecanvas', '04/07/2015', 'userMedia/clipcanvas_14348_offline.mp4', 'userPhoto/good_for_the_books_images.png', 'https://www.google.co.in/?gws_rd=ssl'),
(23, 'new media12', '04/17/2015', 'userMedia/small.mp4', 'userPhoto/usericon.png', 'https://www.youtube.com/?gl=IN');

-- --------------------------------------------------------

--
-- Table structure for table `pictures`
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `pictureid` int(11) NOT NULL AUTO_INCREMENT,
  `picture_path` varchar(256) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`pictureid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `pictures`
--

INSERT INTO `pictures` (`pictureid`, `picture_path`, `userid`) VALUES
(5, 'admin/userPhoto/1427465884195120471.jpg', 1),
(6, 'admin/userPhoto/1427466034552079149.jpg', 1),
(7, 'admin/userPhoto/142746615847883887.jpg', 1),
(11, 'admin/userPhoto/1427897320364688685.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE IF NOT EXISTS `user_details` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `picture` varchar(256) NOT NULL,
  `access` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `gender` varchar(256) NOT NULL,
  `company` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `about` varchar(256) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`userid`, `username`, `password`, `picture`, `access`, `title`, `gender`, `company`, `email`, `phone`, `about`) VALUES
(1, 'ghdjd123', 'xyz', 'admin/userPhoto/14279002051401354028.jpg', 1, 'hdudud', 'male', 'gdhdj', 'xyz@gmail.com', '6464465', 'hdhdj'),
(2, '', '', 'admin/userPhoto/1427465526121117188.jpg', 1, 'aaaa', 'male', 'amb', 'abc@gmail.com', '62462644', 'ddsadas'),
(3, '', '', 'admin/userPhoto/1427465526121117188.jpg', 1, 'ss', 'male', 'sss', 'abc@gmail.com', '23222332', 'sdsdsd');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
