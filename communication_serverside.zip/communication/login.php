<?php
    
    require_once("pi_classes/Town.php");
    
    $objTown=new Town();
    $objTown1=new Town();
    
   $objTown->chkUserLogin();
	
	if($objTown->getRow()>0){
		if($objTown->getField('access')=='1'){
			echo $objTown->getField('userid');
			exit;
		}
		else{
			echo $objTown->getField('access');
			exit;
		}
	}else{
        $objTown1->addUser();
		echo '0';
		exit;
	}
?>