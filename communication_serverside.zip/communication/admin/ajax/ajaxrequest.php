<?php
	require_once("../../pi_classes/Town.php");
	
	$objTown=new Town();


if($_POST['name']=='productinfo') { 

	echo $ajaxRes=$objTown->delproductinfo($_POST);
}

if($_POST['name']=='delPalinsesto') { 

	//echo $ajaxRes=$objTown->delmastershow($_POST);
	echo $ajaxRes=$objTown->delPalinsesto($_POST);
}

if($_POST['name']=='podcastgroup') { 

	echo $ajaxRes=$objTown->delpodcastgroup($_POST);
}

if($_POST['name']=='delstaff') { 

	echo $ajaxRes=$objTown->delstaff($_POST);
}

if($_POST['name']=='deletepodcast') { 

	echo $ajaxRes=$objTown->deletepodcast($_POST);
}
?>