<?php
session_start();
require_once('../pi_classes/Admin.php');

if(isset($_POST['newPass']))
{
	$objAdmin=new Admin();
	if($objAdmin->changePassword("1",$_POST['newPass']))
	{
		echo '101';
	}
}


?>