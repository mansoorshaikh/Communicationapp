function move(fbox, tbox) {
     var arrFbox = new Array();
     var arrTbox = new Array();
     var arrLookup = new Array();
     var i;
	 var fg=tbox.options.length;
	 //alert(fg);
     for(i=0; i<tbox.options.length; i++) {
	 //alert(arrLookup[tbox.options[i].text]);
          arrLookup[tbox.options[i].text] = tbox.options[i].value;
          arrTbox[i] = tbox.options[i].text;
     }
     
	 var fLength = 0;
     var tLength = arrTbox.length
     //alert(tLength);
	 for(i=0; i<fbox.options.length; i++) {
          //alert([fbox.options[i].text]);
		  arrLookup[fbox.options[i].text] = fbox.options[i].value;
          if(fbox.options[i].selected && fbox.options[i].value != "") {
               arrTbox[tLength] = fbox.options[i].text;
			   //alert(arrTbox[tLength]);
               tLength++;
          } else {
               arrFbox[fLength] = fbox.options[i].text;
               fLength++;
          }
     }
     arrFbox.sort();
     arrTbox.sort();
     fbox.length = 0;
     tbox.length = 0;
	 //alert(arrFbox[c]);
     var c;
     for(c=0; c<arrFbox.length; c++) {
          var no = new Option();
          no.value = arrLookup[arrFbox[c]];
		 //alert(no.value);
          no.text = arrFbox[c];
         //alert(no.text);
		  fbox[c] = no;
     }
     for(c=0; c<arrTbox.length; c++) {
     	var no = new Option();
     	no.value = arrLookup[arrTbox[c]];
     	no.text = arrTbox[c];
     	tbox[c] = no;
     }
}

function selectAll(box) {
     for(var i=0; i<box.length; i++) {
     box[i].selected = true;
     }
}

function POP_UP(url)
{
newwindow=window.open(url,'RecordViewer','location=1,maximize=1,status=1,scrollbars=1,width='+screen.width+',height='+screen.height+'');
if (window.focus) {newwindow.focus()}

}

function Is_Numeric(string)
{
	var valid_chars="0,1,2,3,4,5,6,7,8,9,-,., ";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}//IsNumericForPh 


function Is_Numeric_forPrice(string)
{
	var valid_chars="1,2,3,4,5,6,7,8,9,10";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}


function check_size(string,min_size,max_size)
{
var is_size=true;
var len=string.length;
if(len<min_size || len>max_size)
{
is_size=false;
}
return is_size;
}




function IsNumericfor_pst(string)
{
	var valid_chars="0,1,2,3,4,5,6,7,8,9,-,(,), ";
	var isnum=true;
var last_len=string.length-1;

var dfg=string.charAt(last_len);
	//alert(dfg);
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
	
		if(valid_chars.indexOf(char)==-1 && isnum==true)
		{
		isnum=false;
		}
		
		if((i==0) && (valid_chars.indexOf(char)==-1) )
		{
		
		var asci=string.charCodeAt(char);
		
			if(asci>=65 && asci <= 90)
			{
			isnum=true;
			}
			else
			{
			isnum=false;
			}
		}
	}

for(var i=0;i < string.length && isnum==true;i++)
	{

	}

return isnum;
}

function IsNumericForPh(string)
{
	var valid_chars="0,1,2,3,4,5,6,7,8,9,(,),-,+, ";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}//
function IsNumericForPh1(string)
{
	//var valid_chars="0,1,2,3,4,5,6,7,8,9,(,),+,a,b,c";
	var valid_chars="abcdefghijklmnopqrstuvwxyz0123456789- ";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}//

function Is_Numeric_forPrice1(string)
{
	var valid_chars="1,2,3,4,5,6,7,8,9,10,.";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}

function IsSpecialChar_forUsername(string)
{
var spchar="*|,\":<>[]{}`\';()@&$#%0-+! ";
var isvalid=true;
	for(var i=0;i < string.length && isvalid==true;i++)
	{
	var char=string.charAt(i);
		if(spchar.indexOf(char)!=-1)
		{
		isvalid=false;
		}
	}
return isvalid;
}

function Is_URL(string)
{

var val=string;
var urlregex = new RegExp("^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)");
if(urlregex.test(val))
return true;
else
return false;

}

function Is_email(string)
{

var val=string;
var urlregex = new RegExp("^([A-Za-z0-9_/-/.])+/@([A-Za-z0-9_/-/.])+/.([A-Za-z]{2,4})$");
if(urlregex.test(val))
return false;
else
return true;

}
function Is_Extension(string)
{
var exten=true;
			strFilePath = string;
			if (strFilePath.indexOf('.') >=0)
			{
				strFileExtension = strFilePath.slice(strFilePath.lastIndexOf('.')+1, strFilePath.length).toLowerCase();
			} 
			else
			{
				strFileExtension = '';
			}
						 
		    if(strFileExtension != 'jpg' && strFileExtension != 'jpeg' && strFileExtension != 'JPG' && strFileExtension != 'JPEG' && strFileExtension != 'gif' && strFileExtension != 'GIF' && strFileExtension != 'png' && strFileExtension != 'PNG')
			 {  
				//alert('Please upload image of type (jpg/jpeg/JPG/JPEG/gif/GIF/png/PNG).');  
				exten=false;
			}	

	return exten;
}

function Is_Email2(string)
{
   var is_email=true;
	
	 var reEmail=/^[a-z]+(([a-z_0-9]*)|([a-z_0-9]*\.[a-z_0-9]+)|([a-z_0-9]*\-[a-z_0-9]+))*@([a-z_0-9\-\.]+)((\.[a-z]{3})|((\.[a-z]{2})+)|(\.[a-z]{3}(\.[a-z]{2})+))$/;
		if(!reEmail.test(string))
		{
			is_email=false;
			
		}
	return is_email;
}
function Is_Google_IM(string)
{
   var is_email=true;
	
	 var reEmail=/^[a-z]+(([a-z_0-9]*)|([a-z_0-9]*\.[a-z_0-9]+)|([a-z_0-9]*\-[a-z_0-9]+))*@(['gmail'\-\.]+)((\.[a-z]{3})|((\.[a-z]{2})+)|(\.[a-z]{3}(\.[a-z]{2})+))$/;
		if(!reEmail.test(string))
		{
			is_email=false;
			
		}
	return is_email;
}

function Is_Yahoo_IM(string)
{
   var is_email=true;
	
	 var reEmail=/^[a-z]+(([a-z_0-9]*)|([a-z_0-9]*\.[a-z_0-9]+)|([a-z_0-9]*\-[a-z_0-9]+))*@(['yahoo'\-\.]+)((\.[a-z]{3})|((\.[a-z]{2})+)|(\.[a-z]{3}(\.[a-z]{2})+))$/;
		if(!reEmail.test(string))
		{
			is_email=false;
			
		}
	return is_email;
}

function IsNumericForSize(string)
{
	var valid_chars="0,1,2,3,4,5,6,7,8,9,.,+,-,";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}

function IsSpecialChar(string)
{
var spchar=".*|,\":<>[]{}`\';()@&$#%0-+_";
var isvalid=true;
	for(var i=0;i < string.length && isvalid==true;i++)
	{
	var char=string.charAt(i);
		if(spchar.indexOf(char)!=-1)
		{
		isvalid=false;
		}
	}
return isvalid;
}

function get_Element(id)
{
	return document.getElementById(id);
}

function validate_page()
{
var arrArgs;
var myarg=validate_page.arguments;
var Vd=true;

	for(var arg=0;arg<myarg.length;arg++)
	{

		arrArgs=myarg[arg].split(",");
		//alert(arrArgs);
		//alert(arrArgs[0]);
		//alert(arrArgs[1]);		
		//alert(arrArgs[2]);		

	
		if(arrArgs[1]=="blank")
		{
			if(get_Element(arrArgs[0]).value=="")
			{
			alert(arrArgs[2]);
			get_Element(arrArgs[0]).focus();
			Vd=false;
			break;
			}
		}

		if(arrArgs[1]=="sp_char" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var str=get_Element(arrArgs[0]).value;
			var rd=IsSpecialChar(str);
				if(rd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}

		}

	if(arrArgs[1]=="sp_char_user" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var str=get_Element(arrArgs[0]).value;
			var rd=IsSpecialChar_forUsername(str);
				if(rd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}

		}
		if(arrArgs[1]=="num" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=Is_Numeric(num_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		
		if(arrArgs[1]=="num_price" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=Is_Numeric_forPrice1(num_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

	if(arrArgs[1]=="num_pst" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=IsNumericfor_pst(num_value);
			//var nd=IsNumericForPh1(num_value);	
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
	
	if(arrArgs[1]=="num_pst1" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			//var nd=IsNumericfor_pst(num_value);
			var nd=IsNumericForPh1(num_value);	
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

	
	if(arrArgs[1]=="size_pst" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=check_size(num_value,5,10);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		
		if(arrArgs[1]=="size_cc" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=check_size(num_value,3,3);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

		if(arrArgs[1]=="size_num" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=IsNumericForSize(num_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

	if(arrArgs[1]=="size_user" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=check_size(num_value,5,35);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}





		if(arrArgs[1]=="ph" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var num_value=get_Element(arrArgs[0]).value;
			var nd=IsNumericForPh(num_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

		if(arrArgs[1]=="email_chk" && Vd==false)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=Is_Email2(e_value);
				if(nd==true)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		
		if(arrArgs[1]=="Is_GoogleIM" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=Is_Google_IM(e_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		
		if(arrArgs[1]=="Is_YahooIM" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=Is_Yahoo_IM(e_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		
		
		if(arrArgs[1]=="size_phone" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=check_size(e_value,5,40);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

	if(arrArgs[1]=="extension_chk" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=Is_Extension(e_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}

if(arrArgs[1]=="URL_chk" && Vd==true)
		{
			if(get_Element(arrArgs[0]).value!="")
			{
			var e_value=get_Element(arrArgs[0]).value;
			var nd=Is_URL(e_value);
				if(nd==false)
				{
				alert(arrArgs[2]);
				get_Element(arrArgs[0]).focus();
				Vd=false;
				break;
				}
			}		
		}
		



	}
return Vd;

 }


	

function showResponse_rep(varObj)
{
	var resp_rep = varObj.responseText;

	return resp_rep;

		
}

function Confirm_Delete(field)
{
	if(confirm(Do_You_Really_want_to_delete+" "+field))
	{
	return true;
	}
	else
	{
	return false;
	}
}

function is_date(string)
{
	var f=0;
var valid_chars="/";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		}
		else
		{
		f++;
		}
		
	}
	if(f==2)
	{
	var ck=false;
	var str=string.split("/");
		for(var t=0;t<str.length;t++)
		{
		ck=Is_num_(str[t]);			
		}
		isnum=ck;
	}
	else
	{
	isnum=false;
	}
	return isnum;
}

function Is_num_(string)
{
	var valid_chars="0,1,2,3,4,5,6,7,8,9";
	var isnum=true;
	for(var i=0;i < string.length && isnum==true;i++)
	{
	var char=string.charAt(i);
		if(valid_chars.indexOf(char)==-1)
		{
		isnum=false;
		}
	}
return isnum;
}//IsNumericForPh 


