<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
    include('include/header.php');
    ?>
<script language="javascript" type="text/javascript">

function validateFields(){
    if(document.getElementById('medianame').value=="" || document.getElementById('youtubevideo').value=="" ){
        alert('Please fill in all the fields');
    }
    else{
		document.forms['theForm'].submit();
    }
}



</script>

 <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
 
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script></head><body>
  
<form method="post" action="addmedia_page.php?mediaid=<?PHP echo $_REQUEST['mediaid']; ?>" name="theForm" enctype="multipart/form-data">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">

<tbody>
<tr>
<td class="row-header" colspan="2">Add Media</td>
</tr>
<tr>
<td colspan="2" align="left">
<a href="managemedia.php" title="Back " style="font-weight:bold;text-decoration:none;" >&laquo; Back</a>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Media Name</td>
<td class="row1">
<input name="medianame" id="medianame" type="text"  value="<?PHP echo $_REQUEST['medianame']; ?>">
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Upload Media</td>
<td class="row1">
     <input type="file" name="file" id="file"/> 
	 <?PHP if($_REQUEST['mediapath']!=""){ ?>
	  <video width="320" height="240" controls>
  <source src="http://www.mobiwebcode.com/communication/admin/<?PHP echo $_REQUEST['mediapath']; ?>" type="video/mp4">
</video> 

<?PHP } ?>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Upload Picture</td>
<td class="row1">
 <input type="file" name="fileToUpload" id="fileToUpload" size="40">
<?PHP if($_REQUEST['mediapicture']!=""){ ?>
	<img src="http://www.mobiwebcode.com/communication/admin/<?PHP echo $_REQUEST['mediapicture']; ?>" width="100px" height="100px"/>

<?PHP } ?>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Youtube Video[Upload Link]</td>
<td class="row1">
<input name="youtubevideo" id="youtubevideo" type="text"  value="<?PHP echo $_REQUEST['youtubevideo']; ?>">
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;"></td>
<td class="row1">
<input name="btnsubmit" value="Submit" align="left" type="button" onclick="validateFields()"></td>
</tr>



</tbody></table>

</form>

</body></html>