<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	
	$objTown->deletefeedtype_function($_REQUEST['feedtypename']);
	
	 header('Location: managefeedtypes.php');
	
    ?>