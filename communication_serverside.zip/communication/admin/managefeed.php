<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
    
    ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<title>Credit Card Details</title>
<?php
    include('include/header.php');
    ?>
</head><body>

<script>
function deleteClipCat(id)
{
    if(confirm('Do you really want to delete this category.'))
    {
		location.href='deleteClipartCat.php?catId='+id;
		return;
    }
}
function delPalinsesto(id)
{
    if(confirm('Are you sure you want to delete this category'))
	{
		var Host='<?php echo AbstractDB::SITE_PATH; ?>';
		
		$.ajax({
               type: "post",
               url: "ajax/ajaxrequest.php",
               data: "sr="+id+"&name=delPalinsesto",
               success:function(msg) {
               //	alert(msg);
               window.location.reload();
               }
               });
	}
}

</script>

<center><b><font color="#ff0000">
</font></b></center>
<table style="width: 100%;" class="forumline" cellspacing="0">
<tbody><tr>
<td class="row-header" colspan="2"><span>Manage Feed</span></td>
</tr>

<tr>
<td class="message_info" colspan="2" align="center">

</td>
</tr>


<tr><td>&nbsp;
<center><b><font color="#ff0000">
</font></b></center>

</td></tr>

<td class="row1" colspan="2">
<center>
<table style="width: 700px;">
<tbody>
<tr>
<td colspan="2" align="left"><font size="2"><b> <a href="addfeed.php" title="Add New Details" style="text-decoration:none;font-weight:bold;">Add Feed &raquo;  </a></b></font> </td>
</tr>
<tr>
<th width="50">Sr.No</th>
<th width="200">Feed Type</th>
<th width="200">Feed Text</th>
<th width="200">Feed Date</th>
<th width="200">Feed Description</th>
<th width="200">Feed Format</th>
<th width="200">Feed Image</th>
<th width="200">Action</th>

</tr>
<?php
    $objTown->managefeedfunction();
    
    $i=0;
    while($objTown->getRow())
    {
           ?>
<tr>
<td class="row1" style="font-size: 9pt;text-align:center;">
<?php echo ++$i; ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('feedtype'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('feedtext'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('time'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('feeddescription'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('feedformat'); ?>
</td>

<td class="row1" style="font-size: 9pt;">

<img src="http://www.mobiwebcode.com/communication/admin/<?PHP echo $objTown->getField('feedpicture'); ?>" width="100px" height="100px"/>
</td>

<td class="row1" style="font-size: 9pt;">
<a href="addfeed.php?feedid=<?PHP echo $objTown->getField('feedid'); ?>&feedtype=<?PHP echo $objTown->getField('feedtype'); ?>&feedpicture=<?PHP echo $objTown->getField('feedpicture'); ?>&feedtext=<?PHP echo $objTown->getField('feedtext'); ?>&time=<?PHP echo $objTown->getField('time'); ?>&	feeddescription=<?PHP echo $objTown->getField('feeddescription'); ?>&feedformat=<?PHP echo $objTown->getField('feedformat'); ?>"> Edit </a>
<a href="deletefeed.php?feedid=<?PHP echo $objTown->getField('feedid'); ?>"> Delete </a>

</tr>
<?php
    }
    ?>

</tbody>

</table>
</center>
</td>
</tr>

<script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>
</tbody></table></body></html>