
    <div class="main-down-part"></div>
    <div id="footer">
    	<a href="#"><div class="footer-get-in-bg">
        	<div class="footer-get-in-heading">Download from Google Play Button</div>
            <div class="footer-get-in-button"><img src="../images/get-in.jpg" alt="" /></div>
        </div></a>
        <a href="#"><div class="footer-get-in-bg">
        	<div class="footer-get-in-heading">Download from Appstore Button</div>
            <div class="footer-get-in-button"><img src="../images/download.jpg" alt="" /></div>
        </div></a>
        <a id="contact" class="iframeClass" href="video.htm" rel="nofollow"><div class="footer-video-bg">
        	<div class="footer-video-button"><img src="../images/video.jpg" alt="" /></div>
            <div class="footer-video-heading">Video Demo</div>
        </div></a>
    </div>
</div>
</div>
