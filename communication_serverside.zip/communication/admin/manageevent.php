<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
    
    ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<title>Credit Card Details</title>
<?php
    include('include/header.php');
    ?>
</head><body>

<script>
function deleteClipCat(id)
{
    if(confirm('Do you really want to delete this category.'))
    {
		location.href='deleteClipartCat.php?catId='+id;
		return;
    }
}
function delPalinsesto(id)
{
    if(confirm('Are you sure you want to delete this category'))
	{
		var Host='<?php echo AbstractDB::SITE_PATH; ?>';
		
		$.ajax({
               type: "post",
               url: "ajax/ajaxrequest.php",
               data: "sr="+id+"&name=delPalinsesto",
               success:function(msg) {
               //	alert(msg);
               window.location.reload();
               }
               });
	}
}

</script>

<center><b><font color="#ff0000">
</font></b></center>
<table style="width: 100%;" class="forumline" cellspacing="0">
<tbody><tr>
<td class="row-header" colspan="2"><span>Manage Event</span></td>
</tr>

<tr>
<td class="message_info" colspan="2" align="center">

</td>
</tr>


<tr><td>&nbsp;
<center><b><font color="#ff0000">
</font></b></center>

</td></tr>

<td class="row1" colspan="2">
<center>
<table style="width: 700px;">
<tbody>
<tr>
<td colspan="2" align="left"><font size="2"><b> <a href="addnewevent.php" title="Add New Merchant Details" style="text-decoration:none;font-weight:bold;">Add New Event&raquo;  </a></b></font> </td>
</tr>
<tr>
<th width="50">Sr.No</th>
<th width="200">Event date</th>
<th width="200">Event time</th>
<th width="200">Event text</th>
<th width="200"> Action</th>
</tr>
<?php
    $objTown-> EventFunction();
    
    $i=0;
    while($objTown->getRow())
    {
           ?>
<tr>
<td class="row1" style="font-size: 9pt;text-align:center;">
<?php echo ++$i; ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('calendareventdate'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('calendareventtime'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $objTown->getField('calendareventtext'); ?>
</td>

<td class="row1" style="font-size: 9pt;">
<a href="addnewevent.php?calendareventid=<?PHP echo $objTown->getField('calendareventid'); ?>&calendareventdate=<?PHP echo $objTown->getField('calendareventdate'); ?>&calendareventtime=<?PHP echo $objTown->getField('calendareventtime'); ?>&calendareventtext=<?PHP echo $objTown->getField(
'calendareventtext'); ?>"> Edit </a>
<a href="deleteevent.php?calendareventid=<?PHP echo $objTown->getField('calendareventid'); ?>"> Delete </a>

</td>




</tr>
<?php
    }
    ?>

</tbody>

</table>
</center>
</td>
</tr>

<script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>
</tbody></table></body></html>