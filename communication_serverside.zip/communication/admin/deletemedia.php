<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	
	$objTown->deletemedia_function();
	
	 header('Location: managemedia.php');
	
    ?>