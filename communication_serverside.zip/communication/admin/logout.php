<?php
ob_start();
session_start();
unset($_SESSION['adminId']);


?>
<script>
top.location.href='login.php';
</script>
