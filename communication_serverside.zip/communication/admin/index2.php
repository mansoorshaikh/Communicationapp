<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Rodeo</title>
<link href="../css/style2.css" type="text/css" rel="stylesheet"/>
<script type="text/javascript" src="../js/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../js/jquery.fancybox-1.3.1.js"></script>
<link rel="stylesheet" type="text/css" href="../css/jquery.fancybox-1.3.2.css" media="screen">
<script language="javascript">
	$(window).load(function() {
		$("#ContentBoxContainer").mCustomScrollbar("vertical",200,"easeOutCirc",1.25,"fixed","yes","no",0);
	});

	$(document).ready(function() {
		$(".iframeClass").fancybox({
			'height'			    : 301,
			'width'               : 587,
			'autoScale'		: false,
			'padding'			: 0,
			'type'				: 'iframe'
		});
	});
</script>
</head>

<body style=" background: none repeat scroll 0 0 #FFFFFF;">

<?php
include "header.php";
?>

       
    <div id="main-part">
	<?php include "top_nav.php"; ?>
    	<div id="left-part">
        	<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub1','hidetext1')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Own Configurations</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext1">[-]</span>

		</td>

	</tr>

	</tbody></table>  

	<div class="submenu" id="sub1">

		<ul class="navlist">

				  <li><a href="change_admin_details.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8"> Change Admin Details</a></li>

	  </ul>

	</div>


	
           
 <table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub2','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Rodeo List</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub2">

		<ul class="navlist">

				  <li><a href="rodeo_list.php"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Rodeos</a></li>

	  </ul>

    <ul class="navlist">

                 <li><a href="event.php?rodeoid=1"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Events</a></li>

    </ul>

    <ul class="navlist">

    <li><a href="contentlist.php?eventid=1&rodeoid=1"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Contestants</a></li>

    </ul>


	</div>
        </div>
        <div id="right-part">
        	
            <div class="right-text">
			<?php include "home.php"; ?>
            </div>
            
        </div>
    </div>

<?php
include "footer.php";
?>
</body>
</html>