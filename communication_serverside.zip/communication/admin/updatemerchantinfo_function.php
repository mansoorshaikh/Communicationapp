<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $objTown->updateMerchantFunction($_REQUEST['merchantname'],$_REQUEST['merchantid'],$_REQUEST['merchantdesc']);
    
    echo 101;
    ?>