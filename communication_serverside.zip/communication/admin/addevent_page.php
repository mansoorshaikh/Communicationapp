<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	if($_REQUEST['calendareventid']!=""){
			$objTown->updateeventdetails();
			echo 102;
		}else{
 		   $sourceid=$objTown->addevent_function($_REQUEST['calendareventdate'],$_REQUEST['calendareventtime'],$_REQUEST['calendareventtext']);
			echo 101;
		}
    ?>