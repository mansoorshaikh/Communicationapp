<?php
ob_start();
	require_once("../pi_classes/Town.php");

	$objTown=new Town();
$allowedExts = array("jpg", "jpeg", "gif", "png", "mp3", "mp4", "wma");
$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
$uploadOk = 1;
echo $_FILES["file"]["type"]." size".$_FILES["file"]["size"]." extension".$extension ;
$videopath="userMedia/" . $_FILES["file"]["name"];
if ((($_FILES["file"]["type"] == "video/mp4")
|| ($_FILES["file"]["type"] == "audio/mp3") 
|| ($_FILES["file"]["type"] == "audio/wma")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg"))
&& ($_FILES["file"]["size"] < 20000000000)
&& in_array($extension, $allowedExts))

  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

    if (file_exists("userMedia/" . $_FILES["file"]["name"]))
      {
      	echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "userMedia/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "userMedia/" . $_FILES["file"]["name"];
      }
    }
  }
else
  {
   echo "Invalid file";
   $uploadOk = 0;
  }
  
  if($_REQUEST['mediaid']!=""){
  $uploadOk = 1;
  }
if($uploadOk==1){ 
$target_dir = "userPhoto/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check if image file is a actual image or fake image
echo  getimagesize($_FILES["fileToUpload"]["tmp_name"]);

    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
	
	    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
	
	
	echo "updatemediadata_function".$uploadOk;
	if($uploadOk==1){ 
		if($_REQUEST['mediaid']=="")
		$objTown->addmedia_function($videopath,$target_file);
	}else{
	if($uploadOk==1)
		$objTown->updatemedia_function($videopath,$target_file);
	else
		$objTown->updatemediadata_function();
		
	}
	 header('Location: managemedia.php');
	
  }
?>