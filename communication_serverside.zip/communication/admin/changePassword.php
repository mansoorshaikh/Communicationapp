<?PHP
ob_start();
session_start();

require_once('../pi_classes/Admin.php');

if(isset($_POST['oldPass']))
{
	$objAdmin=new Admin();
	if($objAdmin->changePassword($_SESSION['adminId'],$_POST['newPass']))
	{
		header('location:change_admin_details.php?msg='.md5('changePassword'));	
		exit;
	}
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<?php
include('include/header.php');
?>
<script language="javascript" type="text/javascript">
function validUpdate()
{
							
	if(validate_page('oldPass,blank,Please enter old password.','newPass,blank,Please enter new password.','newPassConfirm,blank,Please enter confirm new password.'))
	{
		if(getElement('newPass').value!=getElement('newPassConfirm').value)
		{
				alert('Both password should be the same.');
				getElement('newPass').focus();
				return false;
		}
		
			$.ajax({
			type: "POST",
			url: "chkOldPassword.php",
			data: "oldPass="+getElement('oldPass').value,
			success: function(msg){
					if(parseInt(msg)==101)
					{
						changePass();
					}
					else
					{
						alert('Please enter valid old password.');	
						getElement('oldPass').focus();
						return false;
					}
				}
			});
	
	}
}

function doSub(e)
{
	if(!e)
	{
		e=window.event;
	}
	
	if(e.keyCode=='13')
	{
		validUpdate();
	}
}

function changePass()
{
	$.ajax({
			type: "POST",
			url: "changePass.php",
			data: "newPass="+getElement('newPass').value,
			success: function(msg){
						location.href='change_admin_details.php?msg=<?php echo md5('changePassword')?>';
				}
			});	
}
</script>
</head><body>
<form method="post" name="theForm22" id="theForm22" action="<?php echo $_SERVER['PHP_SELF']?>">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
    <td class="row-header" colspan="2">Change Password </td>
</tr>
<tr> 
	<td>
    	&laquo;&nbsp;<a href="change_admin_details.php" style="text-decoration:none;font-weight:bold;" title="Back">Back</a>
    </td>
    <td class="message_info" colspan="1" align="center">
   
	</td> 
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">Old Password:*</td>
  <td class="row1"><input name="oldPass" id="oldPass" value="" type="password" onkeypress="doSub(event);"></td>
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">New Password:*</td>
  <td class="row1"><input name="newPass" id="newPass" value="" type="password" onkeypress="doSub(event);">
    </td>
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">Confirm New Password:*</td>
  <td class="row1"><input name="newPassConfirm" id="newPassConfirm" value="" type="password" onkeypress="doSub(event);">
    </td>
</tr>



<tr id="TRusername">
  <td class="row1" style="text-align: right;"></td>
  <td class="row1"><input name="submit" value="Submit" onClick="validUpdate()" align="left" type="button"></td>
</tr>

</tbody></table>

</form>

</body></html>