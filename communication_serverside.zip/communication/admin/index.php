<?php
ob_start();
session_start();
if(!isset($_SESSION['adminId']))
{
	header('location:login.php');
	exit;
}
?>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Administration Panel</title> 
</head>

<frameset rows="70,*" framespacing="0" border="0">
	<frame src="top_nav.php" id="head" name="head" noresize="noresize" frameborder="no" marginheight="0" scrolling="no">
	<frameset cols="240,*" framespacing="0" border="1" bordercolor="#333333">
	<frame src="left_nav.php" id="middelFrm" frameborder="yes" style="border-right: 1px solid rgb(51, 51, 51);" scrolling="auto">
	<frame src="home.php" name="display" frameborder="no" marginwidth="10" marginheight="0" scrolling="auto">
  </frameset></frameset><noframes></noframes>
	<noframes></noframes>
</html>