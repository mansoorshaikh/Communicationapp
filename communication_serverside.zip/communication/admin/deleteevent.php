<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	
	$objTown->deleteevent_function();
	
	 header('Location: manageevent.php');
	
    ?>