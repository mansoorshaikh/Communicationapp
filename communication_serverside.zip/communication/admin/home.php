<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
<title>Administration Panel</title>
<meta http-equiv="cache-control" content="no-cache">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/admin.css" type="text/css">

<style type="text/css">
<!--
.style1 {font-size: 36pt;
	font-weight: bold;
	color: #666666;
}
.style2 {color: #CCCCCC}
-->
</style>
	 
</head><body>
<br>
<div class="style1 style2" align="center">Welcome To Admin Panel </div>
<p style="padding-left:300px; padding-top:40px;"></p>
<table style="width: 100%;" cellspacing="0">
<tbody align="center">
  </tbody>
 </table><br>
</body></html>