<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	if($_REQUEST['mediaid']!=""){
		$objTown->updatemediadetails();
		echo 102;
		}
		
	else{
	    $sourceid=$objTown->addmedia_function($_REQUEST['medianame']);
		echo 101;
	}
    ?>