<?PHP
ob_start();
session_start();
require_once('../pi_classes/Admin.php');
if(isset($_POST['oldPass'])) 
{
	$objAdmin=new Admin();
	$objAdmin->getAdminDetails('1');
	$objAdmin->getRow();
	if($_POST['oldPass']==$objAdmin->getField('password'))
	{
		echo '101';
		die;
	}
}
	echo '100';	
?>