<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
    
    ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
    include('include/header.php');
    ?>
<script language="javascript" type="text/javascript">

function validateFields(){
    if(document.getElementById('feedformat').value=="" || document.getElementById('feedtext').value=="" || document.getElementById('feeddesc').value=="" ){
        alert('Please fill in all the fields');
    }
    else{
		document.forms["theForm"].submit();
    }
}

</script>

 <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script></head><body>
<form method="post" action="addfeed_function.php?feedid=<?PHP echo $_REQUEST['feedid']; ?>" name="theForm" enctype="multipart/form-data">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
<td class="row-header" colspan="2">Add Feed</td>
</tr>
<tr>
<td colspan="2" align="left">
<a href="managefeed.php" title="Back " style="font-weight:bold;text-decoration:none;" >&laquo; Back</a>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Feed Format</td>
<td class="row1">
<select id="feedformat" name="feedformat">
	<?PHP if($_REQUEST['feedformat']=="Question"){ ?>
	 <option value="Question" selected="selected">Question</option>
	<?PHP }else {?>
	<option value="Question">Question</option>
	<?PHP } if($_REQUEST['feedformat']=="Normal"){?>
  <option value="Normal" selected="selected">Normal</option>
<?PHP }else {?>
	<option value="Normal">Normal</option>
	<?PHP }?>
</select> 
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Feed Type</td>
<td class="row1">
<select id="optionid" name="optionid">
<?php
	$objTown->feedtypelistfunction();
	while($objTown->getRow()){
	 if($_REQUEST['feedtype']==$objTown->getField('feedtypename')) {
	   ?>
  		<option value="abc" selected="selected"><?PHP echo $objTown->getField('feedtypename'); ?></option>
  <?php
  }else{?>
  	<option value="abc"><?PHP echo $objTown->getField('feedtypename'); ?></option>
  
 <?php }
  }
  ?>
</select> 
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Feed Text</td>
<td class="row1">
 <input name="feedtext" id="feedtext" type="text" value="<?PHP echo $_REQUEST['feedtext']; ?>">
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Feed Description</td>
<td class="row1">
 <input name="feeddesc" id="feeddesc" type="text" value="<?PHP echo $_REQUEST['feeddescription']; ?>">
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Feed Image[Upload]</td>
<td class="row1">
<input type="file" name="fileToUpload" id="fileToUpload" size="40">
<?PHP if($_REQUEST['feedpicture']!=""){ ?>
	<img src="http://www.mobiwebcode.com/communication/admin/<?PHP echo $_REQUEST['feedpicture']; ?>" width="100px" height="100px"/>

<?PHP } ?>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;"></td>
<td class="row1">
<input name="btnsubmit" value="Submit" align="left" type="button" onclick="validateFields()" ></td>
</tr>

</tbody></table>

</form>

</body></html>