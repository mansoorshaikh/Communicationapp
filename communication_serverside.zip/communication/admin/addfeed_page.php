<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $sourceid=$objTown->addfeed_function($_REQUEST['Feedtype'],$_REQUEST['feedtext'],$_REQUEST['feeddate'],$_REQUEST['feeddescription'],$_REQUEST['feedimage']);
	echo 101;
    ?>