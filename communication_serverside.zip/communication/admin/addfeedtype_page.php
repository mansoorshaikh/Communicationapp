<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
	if($_REQUEST['feedtypeid']!=""){
		$objTown->updatefeeddetails();
		echo 102;
		}
		
	else{
	    $sourceid=$objTown->addfeedtype_function($_REQUEST['feedtypename']);
		echo 101;
	}
    ?>