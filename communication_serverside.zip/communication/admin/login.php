<?php
ob_start();
session_start();

	if(isset($_SESSION['adminId']))
	{
		header('location:index.php');	
		exit;
	}
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Account Login</title>
<link rel="stylesheet" type="text/css" href="css/login.css">	
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/admin.css" type="text/css">
<meta http-equiv="cache-control" content="no-cache">
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>
<script src="js/menuswap.js" language="javascript"></script>
	
<script language="javascript" type="text/javascript">
 function loginMe()
 {
	  	
	  if(document.getElementById('u').value=='')
	  {
			alert('Please enter username.');  
			document.getElementById('u').focus();
			return false;
	  }
	  
	  if(document.getElementById('p').value=='')
	  {
			alert('Please enter password.');  
			document.getElementById('p').focus();
			return false;
	  }
	  
		//alert(username);
       $.ajax({
		type: "POST",
		url: "chkLoginDetails.php",
		data: "userName="+document.getElementById('u').value+"&password="+document.getElementById('p').value,
		success: function(msg){
		 if(parseInt(msg)==101)
		 {
			window.location.href='index.php';
		 }
		 else if(parseInt(msg)==100)
		 {
				 alert('You entered username & password is not valid');	 
				 document.getElementById('u').focus();
				 return false;
		 }
		}
		});
    
 }
 
 function getEvent(e)
{
	if(!e)
	{
		e=window.event;
	}
	
	if(e.keyCode=="13")
	{
		loginMe();	
	}
}
</script>

<style type="text/css">
/*.style1 {font-size: 20pt;
	font-weight: bold;
	color: #666666; background-color:#195B85;
}
.style2 {color: #FFFFFF}*/
body {
	background-color: #fff !important;
	width: 100%;
	height: 100%;
}
</style>

</head><body onload="document.getElementById('u').focus();">
<table style="margin: 100px auto;" width="400" border="0" cellpadding="0" cellspacing="0">
   <tbody><tr>
      <td></td>
      <td style="padding-bottom: 1em;" align="left"></td>
      <td></td>
   </tr>
   <tr>
      <td class="box-top-left">&nbsp;</td><td class="box-top">&nbsp;</td><td class="box-top-right">&nbsp;</td>
   </tr>
   <tr>
      <td class="box-left">&nbsp;</td>
      <td class="box-content">
         <table border="0" cellpadding="0" cellspacing="0">
            <tbody><tr>
               <td colspan="2" style="padding-bottom: 1em;" align="left"><img src="images/window-login.png"></td>
            </tr>
             
            <tr>
               <td class="form-label" style="width: 150px;"><label for="email_address">Username:</label></td>
               <td class="form-value">
                  <input id="u" name="userName" size="30" onkeypress="getEvent(event)" class="string short" type="text">
               </td>
            </tr>
            <tr>
               <td class="form-label"><label for="password">Password:</label></td>
               <td class="form-value">
                  <input id="p" name="password" size="30" onkeypress="getEvent(event)" class="string short" type="password">
               </td>
            </tr>
            <tr>
               <td class="form-label"></td>
               <td class="form-value">
				  <input value="Login" style="width: 120px;" name="act[login]" id="button" onclick="loginMe()"  type="button">
               </td>
            </tr>
            <tr>
               <td class="form-label"></td>
               <td class="form-value">
                  
               </td>
            </tr>
            
         </tbody></table>
      </td>
      <td class="box-right">&nbsp;</td>
   </tr>
   <tr>
      <td class="box-bottom-left">&nbsp;</td>
	  <td class="box-bottom">&nbsp;</td><td class="box-bottom-right">&nbsp;</td>
   </tr>
   <tr>
      <td></td>
      <td style="font-size: 11px; color: rgb(68, 68, 68);" align="left"></td>
      <td></td>
   </tr>
</tbody></table>
</body></html>