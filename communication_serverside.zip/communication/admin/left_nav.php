<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
    $objTown2=new Town();
    
    ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<meta http-equiv="cache-control" content="no-cache">

<script type="text/javascript" src="js/main.js">
var SITE_URL="http://www.mobiwebcode.com/rodeo";
</script>

<link rel="stylesheet" type="text/css" href="css/main.css">

<link rel="stylesheet" href="css/admin.css" type="text/css">

</head><body style="background: rgb(255, 255, 255) none repeat scroll 0% 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; margin-top: 5px;">

 <table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub1','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Admin Details</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub1">

		<ul class="navlist">

				  <li><a href="change_admin_details.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Change Password</a></li>

	  </ul>

	</div>
	
	
	<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub2','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage User List</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub2">

		<ul class="navlist">

				  <li><a href="manageuserlist.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">User List</a></li>

	  </ul>

	</div>
	
		<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub3','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Feed Types</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub3">

		<ul class="navlist">

				  <li><a href="managefeedtypes.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Feed Types</a></li>

	  </ul>

	</div>
	
	
	
	<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub4','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Pictures</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub4">

		<ul class="navlist">

				  <li><a href="managepicture.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Pictures</a></li>

	  </ul>

	</div>
	
	
		<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub5','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Events</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub5">

		<ul class="navlist">

				  <li><a href="manageevent.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Events</a></li>

	  </ul>

	</div>
	
	<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub6','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>

		<td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Media</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub6">

		<ul class="navlist">

				  <li><a href="managemedia.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Media</a></li>
				  
				 
				 
		<table style="width: 100%; cursor: pointer;" class="header" onclick="SwitchMenu('sub7','hidetext3')" cellpadding="4" cellspacing="0">

	<tbody><tr>		 
	    <td style="font-size: 8pt;">

		<img src="images/spacer.gif" alt="" class="sqr" style="vertical-align: middle;" width="8" height="8">

		<span style="vertical-align: middle;"><b>Manage Feed</b></span>

		</td>

		<td style="font-size: 7pt; text-align: right;">

		<span class="cur" id="hidetext3">[-]</span>

		</td>

	</tr>

	</tbody></table>
	
	<div class="submenu" id="sub7">

		<ul class="navlist">

				  <li><a href="managefeed.php" target="display"><img src="images/spacer.gif" alt="" class="sqr2" style="vertical-align: middle;" width="8" height="8">Manage feed</a></li>

	  </ul>

	</div>
	

	  </ul>

	</div>

	</div>

</body></html>