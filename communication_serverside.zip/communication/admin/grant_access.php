 <?PHP
   require_once('../pi_classes/Town.php');
   $objTown=new Town();
   $objTown-> grantaccessfunction();
 
   echo '<meta http-equiv="refresh" content="0;url=manageuserlist.php">';
   ?>