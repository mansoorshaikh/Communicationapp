<?php
    
    require_once("pi_classes/Town.php");
    
    include_once('pi_classes/thumbnail_images.class.php');
    
    $objTown=new Town();
    $objTown1=new Town();
    
    $obj_img=new thumbnail_images();
    
    $newFile=time().mt_rand();
    
    $target_path ="admin/userPhoto/"."".$newFile.".jpg";
    
    $encoded_photo = $_POST['image'];
    
    $photo = base64_decode($encoded_photo);
    
    $file = fopen($target_path, 'wb');
    fwrite($file, $photo);
    fclose($file);
    
    $objTown->chkUserLogin();
    
    if($objTown->getRow()>0){
        if($objTown->getField('access')=='1'){
            echo $objTown->getField('userid');
            exit;
        }
        else{
            echo $objTown->getField('access');
            exit;
        }
    }else{
        $objTown1->addUser_android($target_path);
        echo '0';
        exit;
    }
    ?>