<?php
    
   require_once("pi_classes/Town.php");
    
    include_once('pi_classes/thumbnail_images.class.php');
    
    $objTown=new Town();
    
    $obj_img=new thumbnail_images();
        
    $newFile=time().mt_rand();
    
    $target_path ="admin/userPhoto/"."".$newFile.".jpg";
    
	$encoded_photo = $_POST['image'];
	
	$photo = base64_decode($encoded_photo);

	$file = fopen($target_path, 'wb');
	fwrite($file, $photo);
	fclose($file); 
	
	$objTown->updateuserdetail_Android($target_path,$_REQUEST['userid']);
	   	
	echo "\n user id=".$_REQUEST['userid'];
?>