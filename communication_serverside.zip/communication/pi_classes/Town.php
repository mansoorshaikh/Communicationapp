<?php
	require_once('AbstractDB.php');
	
	class Town extends AbstractDB
	{
		function __construct()
		{
			parent::__construct();
		}
        
        function addUser_android($targetpath){
            $str="insert into user_details(email,password,picture) values('".$_REQUEST['email']."','".$_REQUEST['password']."','".$targetpath."')";
            $this->result=$this->query($str);
        }
        
        function addUser_iphone($contents, $targetpath){
            $str="insert into user_details(email,password,picture) values('".$contents[0]."','".$contents[1]."','".$targetpath."')";
            $this->result=$this->query($str);
        }
        
        function addUser(){
            $str="insert into user_details(email,password,picture) values('".$_REQUEST['email']."','".$_REQUEST['password']."','admin/userPhoto/user.png')";
            $this->result=$this->query($str);
        }
        
        function chkLoginDetails($username,$password){
            $str="select * from admin where username='".$username."' and password='".$password."'";
            echo $str;
            $this->result=$this->query($str);
        }
		
		function chkUserLogin(){
			$str="select * from user_details where email='".$_REQUEST['email']."' and password='".$_REQUEST['password']."'";
            $this->result=$this->query($str);
		}

        function chkUserLoginDetails($model){
            $str="select * from user_details where email='".$model[0]."' and password='".$model[1]."'";
            $this->result=$this->query($str);
        }
        
		function getUserListFunction()
		{
			$str="select * from user_details";
            $this->result=$this->query($str);
		}
        
        function getUserListFunctionwithID()
        {
            $str="select * from user_details where userid=".$_REQUEST['userid'];
            $this->result=$this->query($str);
        }
		
		function getFeedTypeListFunction()
		{
			$str="select * from feedtypes";
            $this->result=$this->query($str);
		}
		
		function picturesFunction()
		{
			$str="select * from pictures";
            $this->result=$this->query($str);
		}
        
		function EventFunction()
		{
			$str="select * from calendar_events";
            $this->result=$this->query($str);
			
		}
		function MediaFunction()
		{
			$str="select * from media";
            $this->result=$this->query($str);
		}
		
		
		function updateuserdetail_Android($target_path,$userid)
		{
			$str="update user_details set username='".$_REQUEST['username']."',picture='".$target_path."',about='".$_REQUEST['about']."',title='".
			$_REQUEST['title']."',gender='".$_REQUEST['gender']."',company='".$_REQUEST['company']."', email='".$_REQUEST['email']."',phone='".
			$_REQUEST['phone']."' where userid=".$userid;
			echo $str;
            $this->result=$this->query($str);
             
		}
		
		
		function updateuserdetail($model1,$target_path)
		{
			$str="update user_details set username='".$model1[0]."',picture='".$target_path."',about='".$model1[1]."',title='".
			$model1[2]."',gender='".$model1[3]."',company='".$model1[4]."', email='".$model1[5]."',phone='".
			$model1[6]."' where userid=".$model1[7];
			echo $str;
            $this->result=$this->query($str);
             
		}

		
		function uploadpicture_Android($target_path)
		{
			$str="insert into pictures (pictureid,picture_path,userid) values(NULL,'".$target_path."',".$_REQUEST['userid'].")";
            $this->result=$this->query($str);
           echo $str;
		}
		
		function uploadpicture($userid,$target_path)
		{
			$str="insert into pictures (pictureid,picture_path,userid) values(NULL,'".$target_path."',".$userid.")";
			echo $str;
            $this->result=$this->query($str);
		}
		
		function getuserdetail()
		{   
			$str="select * from user_details where userid=".$_REQUEST['userid'];
		
            $this->result=$this->query($str);
			
         }
		 
		 	function imagelistfunction()
		{   
			$str="select * from pictures where userid=".$_REQUEST['userid'];
		
            $this->result=$this->query($str);
             
		}
		
		function deleteimage()
		{   
			$str="delete from pictures where pictureid=".$_REQUEST['pictureid'];
		
            $this->result=$this->query($str);
             
		}
		
		 	function feedtypelistfunction()
		{   
			$str="select * from feedtypes";
		
            $this->result=$this->query($str);
             
		}
		
		 function managefeedfunction()
		{   
			$str="select * from feeds";
		
            $this->result=$this->query($str);
             
		}
		
		function grantaccessfunction()
		{
		  $str="update user_details set access=".$_REQUEST['access']." where userid=".$_REQUEST['userid'];
		  $this->result=$this->query($str);
		}
		
		function updateeventdetails()
		{
		  $str="update calendar_events set calendareventdate='".$_REQUEST['calendareventdate']."',calendareventtime='".$_REQUEST['calendareventtime'].	
		  "',calendareventtext='".$_REQUEST['calendareventtext']."' where calendareventid=".$_REQUEST['calendareventid'];
		  $this->result=$this->query($str);
		}
		
		function updatefeeddetails()
		{
		  $str="update feedtypes set feedtypename='".$_REQUEST['feedtypename']."' where feedtypeid=".$_REQUEST['feedtypeid'];
		  $this->result=$this->query($str);
		}
		
		function deleteevent_function()
		{
		  	$str="delete from calendar_events where calendareventid=".$_REQUEST['calendareventid'];
            $this->result=$this->query($str);
		}
		
		function deletefeedtype_function($feedtypename)
		{
		  	$str="delete from feedtypes where feedtypeid=".$_REQUEST['feedtypeid'];
            $this->result=$this->query($str);
		}
		
		function deletefeed_function()
		{
		  	$str="delete from feeds where feedid=".$_REQUEST['feedid'];
            $this->result=$this->query($str);
		}

		function deletemedia_function()
		{
		  	$str="delete from media where mediaid=".$_REQUEST['mediaid'];
            $this->result=$this->query($str);
		}
		
		function addfeedtype_function($feedtypename)
		{
		  	$str="insert into feedtypes(feedtypeid,feedtypename) values (NULL,'".$feedtypename."')";
            $this->result=$this->query($str);
		}
		
		function updatefeeddata_function(){
		  $str="update feeds set feedtype='".$_REQUEST['optionid']."',feedformat='".$_REQUEST['feedformat']."',feedtext='".$_REQUEST['feedtext']."',time='".date("m/d/Y")."',feeddescription='".$_REQUEST['feeddesc']."' where feedid=".$_REQUEST['feedid'];
		  $this->result=$this->query($str);
		}
		
		function updatefeed_function($target_file){
		  $str="update feeds set feedtype='".$_REQUEST['optionid']."',feedformat='".$_REQUEST['feedformat']."',feedtext='".$_REQUEST['feedtext']."',time='".date("m/d/Y"). "',feeddescription='".$_REQUEST['feeddesc']."',feedpicture='".$target_file."' where feedid=".$_REQUEST['feedid'];
		  $this->result=$this->query($str);
		}
		
		function addevent_function($calendareventdate,$calendareventtime,$calendareventtext)
	    {
			$str="insert into calendar_events(calendareventid,calendareventdate,calendareventtime,calendareventtext) values (NULL,'".$calendareventdate
			."','".$calendareventtime."','".$calendareventtext."')";
            $this->result=$this->query($str);
		}
		
        function updatePassword(){
            $str="update user_details set password='".$_REQUEST['password']."' where userid=".$_REQUEST['userid'];
            $this->result=$this->query($str);
        }
    
		function addfeed($picturepath)
		{
            
		  	$str="insert into feeds(feedid,feedtype,feedformat,feedtext,feedpicture,time,feeddescription) values (NULL,'".$_REQUEST['optionid']."','".
			$_REQUEST['feedformat']."','".$_REQUEST['feedtext']."','".$picturepath."','".date("m/d/Y")."','".$_REQUEST['feeddesc']."')";
			echo $str;
            $this->result=$this->query($str);
		}
		
		function getfeedlist(){
			$str="select * from feeds where feedtype='".$_REQUEST['feedtype']."'";
			$this->result=$this->query($str);
		}

        function getfeedlistwithfeedid($feedid){
            $str="select * from feeds where feedid=".$feedid;
            $this->result=$this->query($str);
        }
        
		function addmedia_function($videopath,$mediapicture)
		{
		  	$str="insert into media(mediaid,medianame,mediadate,mediapath,mediapicture,youtubevideo) values (NULL,'".$_REQUEST['medianame']."','".
			date("m/d/Y")."','".$videopath."','".$mediapicture."','".$_REQUEST['youtubevideo']."')";
            $this->result=$this->query($str);
		}
		
		function updatemedia_function($videopath,$target_file){
		  $str="update media set medianame='".$_REQUEST['medianame']."',mediadate='".date("m/d/Y")."',mediapath='".$videopath.
		  "',mediapicture='".$target_file."',youtubevideo='".$_REQUEST['youtubevideo']."' where mediaid=".$_REQUEST['mediaid'];
		  $this->result=$this->query($str);
		}
		
		function updatemediadata_function(){
		  $str="update media set medianame='".$_REQUEST['medianame']."',mediadate='".date("m/d/Y")."',youtubevideo='".$_REQUEST['youtubevideo']."' where mediaid=".$_REQUEST['mediaid'];
		  echo $str;
		//  die;
		  $this->result=$this->query($str);
		}
		
      function feedservey_function()
		{
			$str="update feeds set response='".$_REQUEST['response']."' where feedid=".$_REQUEST['feedid'];
            $this->result=$this->query($str);
		}
        
        function feedserveywithimage_function($target_path,$model)
        {
            $str="update feeds set response='".$model[1]."',responseimage='".$target_path."' where feedid=".$model[0];
            $this->result=$this->query($str);
        }
    }
    ?>
